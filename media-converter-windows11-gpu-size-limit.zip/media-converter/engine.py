"""Local conversion engine; no Qt or network dependency."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass, field
from fractions import Fraction
from PIL import Image, ImageOps, ImageColor
import psutil
from gpu_pipeline import Pipeline, input_depth, validate_video, inspect_acceleration, candidates, audio_copy_allowed

ROOT = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
VIDEO_CODECS = {
    'H.264': {'CPU': 'libx264', 'NVIDIA': 'h264_nvenc', 'Intel': 'h264_qsv', 'AMD': 'h264_amf'},
    'H.265': {'CPU': 'libx265', 'NVIDIA': 'hevc_nvenc', 'Intel': 'hevc_qsv', 'AMD': 'hevc_amf'},
    'VP9': {'CPU': 'libvpx-vp9', 'Intel': 'vp9_qsv'},
    'AV1': {'CPU': 'libsvtav1', 'NVIDIA': 'av1_nvenc', 'Intel': 'av1_qsv', 'AMD': 'av1_amf'},
}
VIDEO_FORMATS = {'mp4': ['H.264', 'H.265', 'AV1'], 'mkv': list(VIDEO_CODECS),
                 'mov': ['H.264', 'H.265'], 'webm': ['VP9', 'AV1']}
VIDEO_AUDIO = {'mp4': ['aac'], 'mov': ['aac', 'pcm_s16le'],
               'mkv': ['aac', 'libopus', 'flac', 'pcm_s16le'], 'webm': ['libopus']}
AUDIO_FORMATS = {'mp3': 'libmp3lame', 'wav': 'pcm_s16le', 'flac': 'flac', 'm4a': 'aac', 'aac': 'aac', 'opus': 'libopus'}
IMAGE_FORMATS = ['png', 'jpg', 'webp', 'bmp', 'tiff']


def subprocess_options():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def discover_tool(name, override=''):
    if override:
        p = Path(override).expanduser()
        if not p.is_file():
            raise ValueError(f'{name}が見つかりません: {p}')
        return str(p.resolve())
    for folder in (ROOT / 'tools', ROOT):
        p = folder / (name + ('.exe' if os.name == 'nt' else ''))
        if p.is_file():
            return str(p)
    p = shutil.which(name)
    if not p:
        raise ValueError(f'{name}が未設定です。toolsフォルダーへ配置するか、設定で実行ファイルを指定してください。')
    return p


@dataclass
class Settings:
    output_dir: str = ''
    same_folder: bool = False
    ffmpeg: str = ''
    ffprobe: str = ''
    extract_audio: bool = False
    video_format: str = 'mp4'
    codec: str = 'H.264'
    device: str = '自動'
    decode_mode: str = '自動'
    parallel_jobs: int = 1
    size_preset: str = '元のサイズ'
    width: int = 0
    height: int = 0
    keep_aspect: bool = True
    rate_mode: str = '品質'
    target_size_gb: float = 1.0
    quality: int = 23
    video_kbps: int = 5000
    video_keep_bitrate: bool = False
    fps: float = 0
    mute: bool = False
    video_audio: str = 'aac'
    video_audio_kbps: int = 192
    video_audio_keep_bitrate: bool = False
    audio_kbps: int = 192
    audio_keep_bitrate: bool = False
    audio_format: str = 'mp3'
    sample_rate: int = 0
    channels: int = 0
    image_format: str = 'png'
    image_width: int = 0
    image_height: int = 0
    image_aspect: bool = True
    image_quality: int = 90
    background: str = '#ffffff'

    @classmethod
    def from_dict(cls, data):
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Job:
    path: str
    kind: str = '調査中'
    duration: float = 0
    width: int = 0
    height: int = 0
    has_audio: bool = False
    video_bps: int = 0
    audio_bps: int = 0
    start: float = 0
    end: float = 0  # zero: full duration
    status: str = '待機'
    progress: int = 0
    output: str = ''
    error: str = ''
    video_codec: str = ''
    pix_fmt: str = 'yuv420p'
    bit_depth: int = 8
    sar: str = '1:1'
    rotation: int = 0
    hdr: bool = False
    color: dict = field(default_factory=dict)
    audio_codecs: list = field(default_factory=list)
    detail: str = ''
    uid: str = field(default_factory=lambda: uuid.uuid4().hex)


class Cancelled(Exception):
    pass


class Control:
    """Only this task's child process is suspended/terminated. No arbitrary PID."""
    def __init__(self):
        self.lock = threading.RLock()
        self.proc = None
        self.process_paused = False
        self.cancel_current = threading.Event()
        self.cancel_all = threading.Event()
        self.queue_paused = threading.Event()
        self.can_suspend = False

    def set_process(self, proc, can_suspend=False):
        with self.lock:
            self.proc = proc
            self.can_suspend = can_suspend
            self.process_paused = False
            if proc and (self.cancel_current.is_set() or self.cancel_all.is_set()):
                proc.terminate()

    def checkpoint(self):
        if self.cancel_current.is_set() or self.cancel_all.is_set():
            raise Cancelled()

    def suspend(self):
        with self.lock:
            if not self.can_suspend or not self.proc or self.proc.poll() is not None:
                raise ValueError('現在の処理は一時停止できません。キュー停止を使用してください。')
            if not self.process_paused:
                psutil.Process(self.proc.pid).suspend() if os.name == 'nt' else os.kill(self.proc.pid, signal.SIGSTOP)
                self.process_paused = True

    def resume(self):
        with self.lock:
            if self.process_paused and self.proc:
                try:
                    psutil.Process(self.proc.pid).resume() if os.name == 'nt' else os.kill(self.proc.pid, signal.SIGCONT)
                except (psutil.NoSuchProcess, ProcessLookupError):
                    pass
            self.process_paused = False

    def cancel(self, all_jobs=False):
        if all_jobs:
            self.cancel_all.set()
        self.cancel_current.set()
        with self.lock:
            self.resume()
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.kill()
                except ProcessLookupError:
                    pass

    def wait_queue(self):
        while self.queue_paused.is_set() and not self.cancel_all.is_set():
            time.sleep(.1)
        if self.cancel_all.is_set():
            raise Cancelled()


def stream_bitrate(stream):
    """Use the selected stream's bitrate, never the combined container bitrate."""
    candidates = [stream.get('bit_rate')]
    candidates += [v for k, v in stream.get('tags', {}).items() if k.upper().split('-')[0] == 'BPS']
    for value in candidates:
        try:
            rate = int(value)
            if rate > 0:
                return rate
        except (TypeError, ValueError, OverflowError):
            pass
    return 0


def target_size_bytes(settings):
    """Return the requested output-size cap in bytes (1 GUI GB = 1024**3 bytes)."""
    try:
        size_gb = float(settings.target_size_gb)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError('出力サイズ上限は0より大きい数値で指定してください。') from exc
    if not (size_gb > 0) or not (size_gb < float('inf')):
        raise ValueError('出力サイズ上限は0より大きい数値で指定してください。')
    return int(size_gb * (1024 ** 3))


def target_video_kbps(settings, job):
    """Estimate a video bitrate for a size target, leaving safety headroom.

    Audio must be muted or encoded with a bitrate-controlled lossy codec, because
    copied and lossless audio cannot be reliably budgeted in advance.
    """
    length = trim_length(job)
    if length <= 0:
        raise ValueError('指定サイズで変換するには、動画の長さを取得できる必要があります。')
    if settings.mute or not job.has_audio:
        audio_bps = 0
    else:
        if settings.video_audio in ('copy', 'flac', 'pcm_s16le'):
            raise ValueError('指定サイズモードでは音声コピー・FLAC・PCMを使えません。AAC/Opusなどの圧縮音声を選ぶか、「音声を削除」を有効にしてください。')
        per_track = int(bitrate_value(job, '音声', settings.video_audio_kbps,
                                      settings.video_audio_keep_bitrate, settings.video_audio))
        audio_tracks = max(1, len(job.audio_codecs))
        audio_bps = per_track * audio_tracks

    # Keep 12% headroom for mux/container overhead and bitrate variance. The
    # final file is measured and retried if any encoder still exceeds the cap.
    target_bps = target_size_bytes(settings) * 8.0 / length * 0.88
    video_bps = int((target_bps - audio_bps) // 1000) * 1000
    if video_bps < 64_000:
        raise ValueError('指定サイズが小さすぎるか、音声の容量が大きすぎます。上限を増やすか、音声ビットレートを下げてください。')
    return video_bps // 1000


def bitrate_value(job, media, manual_kbps, keep, codec=''):
    if not keep:
        return str(manual_kbps * 1000)
    rate = job.video_bps if media == '動画' else job.audio_bps
    if not rate:
        raise ValueError(f'元の{media}ビットレートを取得できません。「元のビットレートを使う」をOFFにして値を指定してください。')
    if codec == 'libmp3lame' and not 8000 <= rate <= 320000:
        raise ValueError('元の音声ビットレートはMP3の対応範囲（8〜320kbps）外です。元の値の使用をOFFにして指定してください。')
    if codec == 'libopus' and not 500 <= rate <= 512000:
        raise ValueError('元の音声ビットレートはOpusの対応範囲外です。元の値の使用をOFFにして指定してください。')
    return str(rate)


def probe_job(path, ffprobe, control=None):
    job = Job(str(Path(path).resolve()))
    try:
        with Image.open(path) as im:
            job.kind = '画像'
            job.width, job.height = ImageOps.exif_transpose(im).size
            return job
    except (OSError, ValueError):
        pass
    args = [ffprobe, '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **subprocess_options())
    if control:
        control.set_process(proc)
    try:
        stdout, stderr = proc.communicate(timeout=20)
        if control:
            control.checkpoint()
        if proc.returncode:
            raise ValueError('メディア情報を取得できません: ' + stderr.decode('utf-8', 'replace'))
        data = json.loads(stdout)
        streams = data.get('streams', [])
        videos = [s for s in streams if s.get('codec_type') == 'video' and not s.get('disposition', {}).get('attached_pic')]
        audio = [s for s in streams if s.get('codec_type') == 'audio']
        if not videos and not audio:
            raise ValueError('対応する動画・音声ストリームがありません。')
        job.kind = '動画' if videos else '音声'
        job.has_audio = bool(audio)
        job.audio_codecs = [a.get('codec_name', '') for a in audio]
        job.video_bps = stream_bitrate(videos[0]) if videos else 0
        job.audio_bps = stream_bitrate(audio[0]) if audio else 0
        job.duration = float(data.get('format', {}).get('duration') or max([float(s.get('duration') or 0) for s in streams], default=0))
        if videos:
            stream = videos[0]
            job.video_codec = stream.get('codec_name', '')
            job.pix_fmt = stream.get('pix_fmt', '')
            job.bit_depth = input_depth(stream)
            job.sar = stream.get('sample_aspect_ratio', '1:1')
            job.color = {k: stream[k] for k in ('color_primaries', 'color_transfer', 'color_space', 'color_range') if stream.get(k) not in (None, 'unknown', 'unspecified')}
            job.hdr = stream.get('color_transfer') in ('smpte2084', 'arib-std-b67') or any(any(tag in x.get('side_data_type', '').lower() for tag in ('mastering display', 'content light', 'dovi', 'hdr')) for x in stream.get('side_data_list', []))
            job.width, job.height = int(videos[0].get('width', 0)), int(videos[0].get('height', 0))
            try:
                sar = Fraction(videos[0].get('sample_aspect_ratio', '1:1').replace(':', '/'))
                if sar > 0:
                    job.width = round(job.width * float(sar))
            except (ValueError, ZeroDivisionError):
                pass
            rotation = videos[0].get('tags', {}).get('rotate', 0)
            for side in videos[0].get('side_data_list', []):
                rotation = side.get('rotation', rotation)
            job.rotation = int(float(rotation)) % 360
            if job.rotation % 180:
                job.width, job.height = job.height, job.width
        return job
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise ValueError('情報取得が20秒でタイムアウトしました。')
    finally:
        if control:
            control.set_process(None)


def quality_args(encoder, value):
    if encoder.endswith('_nvenc'):
        return ['-rc', 'vbr', '-cq', str(value), '-b:v', '0']
    if encoder.endswith('_qsv'):
        return ['-global_quality', str(value)]
    if encoder.endswith('_amf'):
        return ['-usage', 'transcoding', '-rc', 'cqp', '-qp_i', str(value), '-qp_p', str(value)]
    if encoder == 'libvpx-vp9':
        return ['-crf', str(value), '-b:v', '0', '-deadline', 'good', '-cpu-used', '4']
    if encoder == 'libsvtav1':
        return ['-crf', str(value), '-preset', '10', '-threads', '2', '-svtav1-params', 'lp=2']
    return ['-crf', str(value), '-preset', 'medium', '-threads', '2']


def encoder_candidates():
    result = {enc: (codec, device) for codec, devices in VIDEO_CODECS.items() for device, enc in devices.items()}
    result['libaom-av1'] = ('AV1', 'CPU')
    return result


def checked_process(args, timeout, control):
    """Bounded, cancellable child; always reap it before returning."""
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **subprocess_options())
    control.set_process(proc)
    deadline = time.monotonic() + timeout
    try:
        while True:
            control.checkpoint()
            try:
                stdout, stderr = proc.communicate(timeout=min(.1, max(.001, deadline - time.monotonic())))
                control.checkpoint()
                return subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                if time.monotonic() >= deadline:
                    raise subprocess.TimeoutExpired(args, timeout)
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.communicate()
        control.set_process(None)


def gpu_failure_reason(encoder, detail):
    detail = detail.strip() or 'FFmpegが理由を出力しませんでした。'
    if encoder.endswith('_amf'):
        lower = detail.lower()
        if 'amfrt' in lower or 'amf runtime' in lower:
            hint = 'AMDのAMFランタイムを読み込めません。AMD公式のAdrenalinドライバーを確認してください。'
        elif 'no device' in lower or 'no capable' in lower or 'device not found' in lower:
            hint = 'AMDのエンコード用GPUを利用できません。ドライバーの状態とGPUの認識を確認してください。'
        elif 'not supported' in lower or 'not_supported' in lower or 'unsupported' in lower:
            hint = 'AMD AMFが試験設定を受け付けません。GPU・ドライバー・FFmpegの対応を確認してください。'
        else:
            hint = 'AMD AMFの実行試験に失敗しました。下の詳細でドライバー・FFmpeg・設定の問題を確認してください。'
        return hint + '\n' + detail
    return 'GPUの実行試験に失敗しました。\n' + detail


def check_capabilities(ffmpeg, callback=lambda *a: None, stop=None, control=None):
    control = control or Control()
    available, reasons = {}, {}
    proc = checked_process([ffmpeg, '-hide_banner', '-encoders'], 15, control)
    if proc.returncode:
        raise ValueError('FFmpegのエンコーダー一覧を取得できません。')
    listed = set(re.findall(r'^\s*[VAS][A-Z.]{5}\s+(\S+)', proc.stdout.decode('utf-8', 'replace'), re.M))
    for encoder, pair in encoder_candidates().items():
        if stop and stop.is_set():
            break
        if encoder not in listed:
            reasons[encoder] = 'このFFmpegに含まれていません'
            continue
        gpu = pair[1] != 'CPU'
        size, fps, frames = ('1280x720', '30', '8') if gpu else ('128x128', '10', '2')
        timeout = 15 if gpu else 8
        callback(f'{encoder}を試験中…（{size} / {frames}フレーム）')
        q = quality_args(encoder, 28) if encoder != 'libaom-av1' else ['-crf', '28', '-b:v', '0', '-cpu-used', '8', '-threads', '2']
        args = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i',
                f'color=size={size}:rate={fps}', '-frames:v', frames, '-an', '-c:v', encoder,
                '-pix_fmt', 'nv12' if encoder.endswith('_amf') else 'yuv420p', *q, '-f', 'null', '-']
        try:
            trial = checked_process(args, timeout, control)
            if trial.returncode:
                detail = trial.stderr.decode('utf-8', 'replace')
                reasons[encoder] = gpu_failure_reason(encoder, detail) if gpu else detail or '試験エンコードに失敗'
            else:
                available[encoder] = pair
        except subprocess.TimeoutExpired:
            reasons[encoder] = f'試験が{timeout}秒でタイムアウト。GPUドライバーと利用状況を確認してください。'
    # audio encoders: list presence; actual errors are reported per job
    audio = {enc for enc in AUDIO_FORMATS.values() if enc in listed}
    extra = inspect_acceleration(ffmpeg, control, checked_process, callback)
    for encoder in available:
        try:
            info = checked_process([ffmpeg, '-hide_banner', '-h', 'encoder=' + encoder], 8, control)
            text = (info.stdout + info.stderr).decode('utf-8', 'replace')
            match = re.search(r'Supported pixel formats:\s*([^\r\n]+)', text)
            extra['pixel_formats'][encoder] = match[1].split() if match else []
        except subprocess.TimeoutExpired:
            extra['pixel_formats'][encoder] = []
    return {'video': available, 'audio': sorted(audio), 'reasons': reasons, **extra}


def select_encoder(settings, caps, cpu_only=False):
    requested = 'CPU' if cpu_only else settings.device
    matches = [(enc, pair[1]) for enc, pair in caps['video'].items() if pair[0] == settings.codec]
    priority = ['NVIDIA', 'Intel', 'AMD', 'CPU'] if requested == '自動' else [requested]
    for device in priority:
        for enc, d in matches:
            if d == device:
                return enc, d
    raise ValueError(f'{settings.codec} / {requested}に利用可能なエンコーダーがありません。機能確認を実行してください。')


def trim_length(job):
    if job.start < 0 or job.end < 0 or (job.end and job.end <= job.start):
        raise ValueError('トリミング開始・終了位置が不正です。')
    if job.duration and (job.start >= job.duration or job.end > job.duration + .05):
        raise ValueError('トリミング範囲が素材の長さを超えています。')
    if not job.duration and (job.start or job.end):
        if not job.end:
            raise ValueError('長さ不明の素材は終了位置も指定してください。')
    return (job.end or job.duration) - job.start


def scale_filter(settings, job):
    # Normalize non-square pixels before fitting; merely setsar=1 would stretch them.
    normalize = "scale=w='max(2,trunc(iw*if(gt(sar,0),sar,1)/2)*2)':h='max(2,trunc(ih/2)*2)',setsar=1,"
    w, h = settings.width, settings.height
    if not w and not h and job.sar in ('1:1', '0:1', 'N/A', '') and job.width % 2 == 0 and job.height % 2 == 0:
        return ''
    if settings.size_preset != 'カスタム' and job.height > job.width and w > h:
        w, h = h, w
    if not w and not h:
        return normalize.rstrip(',')
    if not w:
        return normalize + f'scale=-2:{h},setsar=1'
    if not h:
        return normalize + f'scale={w}:-2,setsar=1'
    if settings.keep_aspect:
        return normalize + f'scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1'
    return normalize + f'scale={w}:{h},setsar=1'


def build_command(settings, job, temp, encoder='', pipeline=None):
    ffmpeg = discover_tool('ffmpeg', settings.ffmpeg)
    length = trim_length(job)
    is_audio = job.kind == '音声' or settings.extract_audio
    pipeline = pipeline or Pipeline(filters=scale_filter(settings, job))
    args = [ffmpeg, '-hide_banner', '-loglevel', 'info', '-nostdin', '-n']
    if not is_audio:
        args += list(pipeline.input_args)
    args += ['-i', job.path]
    if job.start:
        args += ['-ss', str(job.start)]  # output seeking: decode for accurate cuts
    if job.end:
        args += ['-t', str(length)]
    if is_audio:
        if not job.has_audio:
            raise ValueError('この素材には音声がありません。')
        codec = AUDIO_FORMATS[settings.audio_format]
        args += ['-map', '0:a:0', '-vn', '-c:a', codec]
        if codec not in ('flac', 'pcm_s16le'):
            args += ['-b:a', bitrate_value(job, '音声', settings.audio_kbps, settings.audio_keep_bitrate, codec)]
        if settings.sample_rate:
            args += ['-ar', str(settings.sample_rate)]
        if settings.channels:
            args += ['-ac', str(settings.channels)]
    else:
        if settings.codec not in VIDEO_FORMATS.get(settings.video_format, []):
            raise ValueError('動画形式とコーデックの組み合わせが不正です。')
        if not encoder:
            raise ValueError('動画エンコーダーが未選択です。')
        validate_video(settings, job, encoder, getattr(pipeline, 'caps', None))
        args += ['-map', '0:V:0', '-c:v', encoder]
        if not pipeline.hardware_frames:
            fmt = ('p010le' if encoder.endswith(('_amf', '_nvenc', '_qsv')) else 'yuv420p10le') if job.bit_depth == 10 else ('nv12' if encoder.endswith('_amf') else 'yuv420p')
            args += ['-pix_fmt', fmt]
        if job.bit_depth == 10 and settings.codec == 'H.265':
            args += ['-profile:v', 'main10']
        if pipeline.filters:
            args += ['-vf', pipeline.filters]
        for key, value in job.color.items():
            args += ['-' + key.replace('color_space', 'colorspace').replace('color_transfer', 'color_trc'), value]
        if settings.rate_mode == 'ビットレート':
            args += ['-b:v', bitrate_value(job, '動画', settings.video_kbps, settings.video_keep_bitrate)]
        elif settings.rate_mode == '指定サイズ（GB）':
            args += ['-b:v', str(target_video_kbps(settings, job) * 1000)]
        elif encoder == 'libaom-av1':
            args += ['-crf', str(settings.quality), '-b:v', '0', '-cpu-used', '8', '-threads', '2']
        else:
            args += quality_args(encoder, settings.quality)
        if settings.fps:
            args += ['-r', str(settings.fps)]
        if settings.mute or not job.has_audio:
            args += ['-an']
        else:
            if settings.video_audio == 'copy' and not audio_copy_allowed(settings.video_format, job.audio_codecs):
                raise ValueError('音声コピーはこの出力形式/音声コーデックに対応していません。AACなどへの変換を選んでください。')
            if settings.video_audio != 'copy' and settings.video_audio not in VIDEO_AUDIO[settings.video_format]:
                raise ValueError('動画形式と音声コーデックの組み合わせが不正です。')
            args += ['-map', '0:a?', '-c:a', settings.video_audio]
            if settings.video_audio not in ('copy', 'flac', 'pcm_s16le'):
                args += ['-b:a', bitrate_value(job, '音声', settings.video_audio_kbps,
                                              settings.video_audio_keep_bitrate, settings.video_audio)]
        if settings.codec == 'H.265' and settings.video_format in ('mp4', 'mov'):
            args += ['-tag:v', 'hvc1']
        if settings.video_format in ('mp4', 'mov'):
            args += ['-movflags', '+faststart']
    return args + ['-progress', 'pipe:1', '-nostats', str(temp)]


def unique_output(job, settings):
    ext = settings.image_format if job.kind == '画像' else settings.audio_format if job.kind == '音声' or settings.extract_audio else settings.video_format
    folder = Path(job.path).parent if settings.same_folder else Path(settings.output_dir or (Path(job.path).parent / 'converted'))
    folder.mkdir(parents=True, exist_ok=True)
    base = folder / (Path(job.path).stem + '_converted.' + ext)
    return base


def publish_file(temp, base):
    """Atomic, no-clobber publication on NTFS and normal local file systems."""
    for n in range(100000):
        target = base if not n else base.with_name(f'{base.stem}_{n}{base.suffix}')
        try:
            os.link(temp, target)
            temp.unlink()
            return target
        except FileExistsError:
            continue
        except OSError as exc:
            # Windows rename is also atomic and refuses an existing destination.
            if os.name == 'nt':
                try:
                    os.rename(temp, target)
                    return target
                except FileExistsError:
                    continue
            raise ValueError('出力先が安全な完成ファイル作成に対応していません。NTFSなどのローカルフォルダーを選んでください。') from exc
    raise ValueError('出力名を確保できません。')


def convert_image(job, settings, temp, control):
    control.checkpoint()
    fmt = settings.image_format
    frames, durations = [], []
    with Image.open(job.path) as source:
        count = getattr(source, 'n_frames', 1)
        animated = bool(getattr(source, 'is_animated', False)) and source.format != 'TIFF'
        if count > 1 and fmt not in ('png', 'webp', 'tiff'):
            raise ValueError('アニメーション・複数ページ画像はPNG / WebP / TIFFのみ対応します。最初のフレームだけを保存しません。')
        if count > 1 and not animated and fmt != 'tiff':
            raise ValueError('複数ページ画像の出力はTIFFのみ対応します。')
        if count > 500 or source.width * source.height * count > 100_000_000:
            raise ValueError('画像の総画素数またはフレーム数が上限を超えています（1億画素 / 500フレーム）。')
        loop = source.info.get('loop', 1)
        poster = bool(source.info.get('default_image', False))
        for index in range(count):
            control.checkpoint()
            source.seek(index)
            if poster and index == 0 and fmt == 'webp':
                continue  # APNG poster is not part of the timed animation.
            im = ImageOps.exif_transpose(source).convert('RGBA')
            w, h = settings.image_width, settings.image_height
            if w or h:
                if settings.image_aspect:
                    factor = min(w / im.width if w else float('inf'), h / im.height if h else float('inf'))
                    size = (max(1, round(im.width * factor)), max(1, round(im.height * factor)))
                else:
                    size = (w or im.width, h or im.height)
                im = im.resize(size, Image.Resampling.LANCZOS)
            if fmt in ('jpg', 'bmp'):
                bg = Image.new('RGB', im.size, ImageColor.getrgb(settings.background))
                bg.paste(im, mask=im.getchannel('A'))
                im = bg
            frames.append(im)
            durations.append(source.info.get('duration', 100))
    control.checkpoint()
    options = {'quality': settings.image_quality} if fmt in ('jpg', 'webp') else {}
    if fmt == 'tiff':
        options['compression'] = 'tiff_deflate'
    if len(frames) > 1:
        options.update(save_all=True, append_images=frames[1:])
        if fmt in ('png', 'webp'):
            options.update(duration=durations[1:] if poster and fmt == 'png' else durations, loop=loop)
        if fmt == 'png':
            options.update(default_image=poster, disposal=0, blend=0)
    frames[0].save(temp, **options)
    control.checkpoint()


def run_ffmpeg(args, length, control, callback, log, cpu):
    log('実行: ' + subprocess.list2cmdline(args))
    with tempfile.TemporaryFile() as error_file:
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=error_file, text=True,
                                encoding='utf-8', errors='replace', **subprocess_options())
        control.set_process(proc, can_suspend=cpu)
        data = {}
        try:
            for line in proc.stdout:
                control.checkpoint()
                key, _, value = line.strip().partition('=')
                data[key] = value
                if key == 'progress':
                    try:
                        seconds = int(data.get('out_time_us', 0)) / 1_000_000
                        speed = float(data.get('speed', '0').rstrip('x'))
                    except ValueError:
                        seconds, speed = 0, 0
                    percent = min(99, max(0, int(100 * seconds / length))) if length > 0 else 0
                    remaining = max(0, (length - seconds) / speed) if length > 0 and speed > 0 else None
                    callback(percent, f'{speed:.2f}倍速 / 残り約{remaining:.0f}秒' if remaining is not None else '処理中（残り時間不明）')
            code = proc.wait()
            error_file.seek(0)
            runtime_log = error_file.read().decode('utf-8', 'replace')
            log('[実変換 FFmpeg実行ログ]\n' + runtime_log)
            control.checkpoint()
            if code:
                error_file.seek(0)
                detail = error_file.read().decode('utf-8', 'replace')
                log('[実変換 FFmpegエラー全文]\n' + detail)
                raise RuntimeError(detail or f'FFmpeg終了コード: {code}')
        finally:
            if proc.poll() is None:
                control.resume()
                proc.kill()
                proc.wait(timeout=5)
            proc.stdout.close()
            control.set_process(None)


def prepare_pipeline(settings, job, temp, encoder, caps, control, log):
    validate_video(settings, job, encoder, caps)
    choices = candidates(settings, job, encoder, caps, scale_filter(settings, job))
    for route in choices:
        route.caps = caps
        if route.name == 'CPU':
            log('[経路選択] ' + route.note + ' 圧縮: ' + encoder)
            return route
        trial = build_command(settings, job, temp, encoder, route)
        # Probe only video, using this input and these exact video settings.
        cut = trial.index('-progress')
        trial = trial[:cut]
        if '-map' in trial and '0:a?' in trial:
            audio_index = trial.index('0:a?') - 1
            end = trial.index('-tag:v') if '-tag:v' in trial else trial.index('-movflags') if '-movflags' in trial else len(trial)
            trial[audio_index:end] = []
        trial += ['-an', '-frames:v', '8', '-f', 'null', '-']
        log('[入力別GPU経路試験] ' + subprocess.list2cmdline(trial))
        try:
            result = checked_process(trial, 30, control)
            detail = result.stderr.decode('utf-8', 'replace')
            log('[入力別GPU経路試験ログ] ' + route.name + '\n' + detail)
            if result.returncode == 0:
                log('[経路選択] ' + route.name + ' の短時間試験成功。実変換の成否とは別です。')
                return route
        except subprocess.TimeoutExpired:
            log('[入力別GPU経路試験] タイムアウト: ' + route.name)
    raise RuntimeError('この入力のGPU経路試験に失敗しました。デコード方式を変更するか、CPUでの再試行を選んでください。')


def convert_job(job, settings, caps, control, progress=lambda *a: None,
                log=lambda *a: None, encoder_changed=lambda *a: None, retry_cpu=lambda *a: False):
    control.checkpoint()
    base = unique_output(job, settings)
    temp = base.with_name(f'.{base.stem}.{uuid.uuid4().hex}.part{base.suffix}')
    try:
        if job.kind == '画像':
            encoder_changed('Pillow', False)
            convert_image(job, settings, temp, control)
        else:
            encoder, device = ('', 'CPU')
            if job.kind == '動画' and not settings.extract_audio:
                encoder, device = select_encoder(settings, caps)
            else:
                if AUDIO_FORMATS[settings.audio_format] not in caps['audio']:
                    raise ValueError('指定した音声エンコーダーがこのFFmpegにありません。')
            if job.kind == '動画' and not settings.extract_audio and not settings.mute and job.has_audio and settings.video_audio != 'copy' and settings.video_audio not in caps['audio']:
                raise ValueError('指定した動画用音声エンコーダーがこのFFmpegにありません。')
            if job.kind == '動画' and not settings.extract_audio and settings.rate_mode == '指定サイズ（GB）':
                # Validate before starting a long encode, including audio budget.
                target_size_bytes(settings)
                target_video_kbps(settings, job)

            encoder_changed(encoder or AUDIO_FORMATS[settings.audio_format], device == 'CPU')

            def encode_once(active_settings):
                try:
                    pipeline = prepare_pipeline(active_settings, job, temp, encoder, caps, control, log) if encoder else None
                    log('[実変換 開始] ' + (encoder or '音声') + (' / ' + pipeline.name + ' / ' + pipeline.note if pipeline else ''))
                    run_ffmpeg(build_command(active_settings, job, temp, encoder, pipeline), trim_length(job), control, progress, log, device == 'CPU')
                except RuntimeError as exc:
                    if not encoder or device == 'CPU':
                        raise
                    control.checkpoint()
                    try:
                        cpu_encoder, _ = select_encoder(active_settings, caps, cpu_only=True)
                    except ValueError:
                        raise exc
                    if not retry_cpu(str(exc)):
                        control.checkpoint()
                        raise exc
                    log('GPU変換に失敗。CPUで再試行: ' + str(exc))
                    temp.unlink(missing_ok=True)
                    encoder_changed(cpu_encoder, True)
                    cpu_settings = copy.deepcopy(active_settings)
                    cpu_settings.decode_mode = 'CPU'
                    pipeline = prepare_pipeline(cpu_settings, job, temp, cpu_encoder, caps, control, log)
                    run_ffmpeg(build_command(cpu_settings, job, temp, cpu_encoder, pipeline), trim_length(job), control, progress, log, True)

            size_mode = job.kind == '動画' and not settings.extract_audio and settings.rate_mode == '指定サイズ（GB）'
            maximum_bytes = target_size_bytes(settings) if size_mode else 0
            # A measured-size retry protects against encoders/muxers whose actual
            # bitrate differs from the estimate. An oversized result is never published.
            max_attempts = 4 if size_mode else 1
            active_settings = copy.deepcopy(settings)
            for attempt in range(max_attempts):
                control.checkpoint()
                temp.unlink(missing_ok=True)
                encode_once(active_settings)
                control.checkpoint()
                if not size_mode:
                    break
                actual_bytes = temp.stat().st_size if temp.is_file() else 0
                if 0 < actual_bytes <= maximum_bytes:
                    if attempt:
                        log(f'[サイズ上限調整] {actual_bytes / (1024 ** 3):.3f} GB / 上限 {settings.target_size_gb:.3f} GB（{attempt}回再変換）')
                    else:
                        log(f'[サイズ上限確認] {actual_bytes / (1024 ** 3):.3f} GB / 上限 {settings.target_size_gb:.3f} GB')
                    break
                if actual_bytes <= 0:
                    raise ValueError('出力ファイルが空です。')
                if attempt + 1 >= max_attempts:
                    raise ValueError(
                        f'出力サイズが上限を超えました（{actual_bytes / (1024 ** 3):.3f} GB / '
                        f'上限 {settings.target_size_gb:.3f} GB）。容量を増やすか、音声設定を見直してください。'
                    )
                # Estimate bitrate scaling from measured size, aiming for 92% of
                # the cap on the next pass. The helper also reserves 12% headroom.
                ratio = maximum_bytes / actual_bytes * 0.92
                active_settings = copy.deepcopy(settings)
                active_settings.target_size_gb = settings.target_size_gb * ratio
                log(f'[サイズ上限調整] 実サイズ {actual_bytes / (1024 ** 3):.3f} GB が上限を超えたため、動画ビットレートを下げて再変換します（{attempt + 1}/{max_attempts - 1}）。')
        control.checkpoint()
        if not temp.is_file() or temp.stat().st_size == 0:
            raise ValueError('出力ファイルが空です。')
        if job.kind == '動画' and not settings.extract_audio:
            verified = probe_job(temp, discover_tool('ffprobe', settings.ffprobe), control)
            if verified.bit_depth != job.bit_depth:
                raise ValueError(f'出力検証失敗: 入力{job.bit_depth}ビットに対し出力{verified.bit_depth}ビットです。完成ファイルとして保存しません。')
            if settings.mute and verified.has_audio:
                raise ValueError('出力検証失敗: 音声削除が反映されていません。')
            if settings.rate_mode == '指定サイズ（GB）':
                actual_bytes = temp.stat().st_size
                maximum_bytes = target_size_bytes(settings)
                if actual_bytes > maximum_bytes:
                    raise ValueError('最終検証で指定サイズの上限超過を検出しました。完成ファイルとして保存しません。')
                log(f'[出力サイズ検証] {actual_bytes / (1024 ** 3):.3f} GB / 上限 {settings.target_size_gb:.3f} GB')
            log(f'[出力検証] {verified.video_codec} / {verified.width}×{verified.height} / {verified.bit_depth}ビット / 音声{len(verified.audio_codecs)}トラック')
        output = publish_file(temp, base)
        progress(100, '完了')
        return str(output)
    finally:
        temp.unlink(missing_ok=True)
