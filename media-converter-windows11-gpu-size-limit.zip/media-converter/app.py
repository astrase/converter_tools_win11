from __future__ import annotations
from dataclasses import asdict
import copy
import json
import os
from pathlib import Path
import sys
import threading
import traceback
from batch_queue import QueueControl, run_queue

from PySide6.QtCore import Qt, QThread, Signal, QUrl, QTimer, QStandardPaths
from PySide6.QtGui import QDesktopServices, QColor, QPixmap, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QSplitter, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QPushButton, QLabel, QLineEdit, QCheckBox, QComboBox, QSpinBox, QDoubleSpinBox,
    QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit, QGroupBox,
    QScrollArea, QAbstractItemView, QSlider, QStackedWidget, QColorDialog,
)
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
from engine import (
    Settings, Job, Control, Cancelled, discover_tool, probe_job, check_capabilities,
    convert_job, VIDEO_FORMATS, VIDEO_AUDIO, VIDEO_CODECS, AUDIO_FORMATS,
    IMAGE_FORMATS, encoder_candidates, select_encoder, trim_length, ROOT,
)


class ScanThread(QThread):
    result = Signal(object)
    error = Signal(str, str)
    def __init__(self, paths, ffprobe):
        super().__init__()
        self.paths, self.ffprobe = paths, ffprobe
        self.control = Control()
    def run(self):
        def expand():
            seen = set()
            for raw in self.paths:
                root = Path(raw)
                files = root.rglob('*') if root.is_dir() else [root]
                for item in files:
                    if self.isInterruptionRequested():
                        return
                    if item.is_file() and str(item.resolve()).casefold() not in seen:
                        seen.add(str(item.resolve()).casefold())
                        yield str(item.resolve())
        for path in expand():
            if self.isInterruptionRequested():
                break
            try:
                self.result.emit(probe_job(path, self.ffprobe, self.control))
            except Cancelled:
                break
            except Exception as exc:
                self.error.emit(path, str(exc))


class CapabilityThread(QThread):
    result = Signal(object)
    message = Signal(str)
    error = Signal(str)
    def __init__(self, ffmpeg):
        super().__init__()
        self.ffmpeg = ffmpeg
        self.stop_event = threading.Event()
        self.control = Control()
    def run(self):
        try:
            self.result.emit(check_capabilities(self.ffmpeg, self.message.emit, self.stop_event, self.control))
        except Cancelled:
            pass
        except Exception as exc:
            self.error.emit(str(exc))


class BatchThread(QThread):
    changed = Signal(str, str, int, str)
    total = Signal(int)
    log = Signal(str)
    active_encoder = Signal(str, bool)
    request_retry = Signal(object)
    def __init__(self, jobs, settings, caps):
        super().__init__()
        self.jobs, self.settings, self.caps = jobs, settings, caps
        self.control = QueueControl()
        self.reply = threading.Event()
        self.allow_retry = False
        self.current_job = None
        self.retry_lock = threading.Lock()
        self.progress_lock = threading.Lock()
        self.percentages = {j.uid: 0 for j in jobs}

    def retry_cpu(self, error, control):
        # Serialize modal questions; each worker retains its own cancellation.
        with self.retry_lock:
            control.checkpoint()
            request = {'detail': error, 'reply': threading.Event(), 'allow': False, 'control': control}
            self.request_retry.emit(request)
            while not request['reply'].wait(.1):
                control.checkpoint()
            control.checkpoint()
            return request['allow']

    def progress(self, job, status, percent, detail):
        with self.progress_lock:
            self.percentages[job.uid] = 100 if status in ('完了', '失敗', '中止') else percent
            self.total.emit(round(sum(self.percentages.values()) / max(1, len(self.jobs))))
        self.changed.emit(job.uid, status, percent, detail)

    def work(self, job, control):
        self.current_job = job
        job.status = '変換中'
        self.progress(job, '変換中', 0, '')
        def enc(name, cpu):
            job.encoder_detail = job.detail = '圧縮: ' + name
            self.active_encoder.emit(Path(job.path).name + ' / ' + name, cpu and self.settings.parallel_jobs == 1)
        try:
            job.output = convert_job(job, self.settings, self.caps, control,
                lambda p, text: self.progress(job, '変換中', p, job.encoder_detail + ' / ' + text),
                lambda text: self.log.emit('[' + Path(job.path).name + '] ' + text), enc,
                lambda error: self.retry_cpu(Path(job.path).name + '\n' + error, control))
            job.error, job.status = '', '完了'
            self.progress(job, '完了', 100, job.output)
        except Cancelled:
            job.status = '中止'
            self.progress(job, '中止', 0, '不完全な出力を削除しました')
        except Exception as exc:
            job.error, job.status = str(exc), '失敗'
            self.log.emit(f'{job.path}\n{traceback.format_exc()}')
            self.progress(job, '失敗', 0, str(exc))
        finally:
            self.control.unregister(job.uid)

    def run(self):
        def skip(job):
            job.status = '中止'
            self.progress(job, '中止', 0, '全体をキャンセル')
        try:
            run_queue(self.jobs, self.settings.parallel_jobs, self.control, self.work, skip)
        finally:
            self.current_job = None
            self.active_encoder.emit('待機', False)


class DropTable(QTableWidget):
    dropped = Signal(list)
    def __init__(self):
        super().__init__(0, 6)
        self.setAcceptDrops(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DropOnly)
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    def dropEvent(self, event):
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        self.dropped.emit(paths)
        event.acceptProposedAction()


def combo(items):
    w = QComboBox()
    w.addItems([str(i) for i in items])
    return w


def spin(maximum=16384, value=0):
    w = QSpinBox()
    w.setRange(0, maximum)
    w.setValue(value)
    return w


def scroll(widget):
    s = QScrollArea()
    s.setWidgetResizable(True)
    s.setWidget(widget)
    return s


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('メディア変換 GPU版 — 動画・画像・音声')
        self.resize(1260, 930)
        self.setMinimumSize(900, 650)
        self.jobs = []
        self.scan = None
        self.cap_thread = None
        self.batch = None
        self.caps = {'video': {}, 'audio': [], 'reasons': {}}
        self.checked_ffmpeg = ''
        self.loading_trim = False
        self.widgets = {}
        self.last_output_dir = ''
        self.config_dir = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppConfigLocation))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_path = self.config_dir / 'settings.json'
        self.log_path = self.config_dir / 'latest.log'
        self.log_path.write_text('', encoding='utf-8')
        self.build_ui()
        self.restore()
        QTimer.singleShot(100, self.detect_capabilities)

    def button(self, text, callback, layout=None):
        b = QPushButton(text)
        b.clicked.connect(callback)
        if layout:
            layout.addWidget(b)
        return b

    def field(self, form, key, label, widget):
        form.addRow(label, widget)
        self.widgets[key] = widget
        return widget

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        heading = QLabel('動画・画像・音声を、まとめて変換')
        heading.setObjectName('heading')
        layout.addWidget(heading)
        layout.addWidget(QLabel('① ファイルを追加　② 設定・トリミング　③ 変換開始　｜　一覧へドラッグ＆ドロップできます'))
        row = QHBoxLayout()
        self.add_btn = self.button('ファイルを追加', self.choose_files, row)
        self.folder_btn = self.button('フォルダー追加', self.choose_folder, row)
        self.up_btn = self.button('↑', lambda: self.move_selected(-1), row)
        self.down_btn = self.button('↓', lambda: self.move_selected(1), row)
        self.retry_btn = self.button('失敗のみ再実行', self.retry_failed, row)
        self.remove_btn = self.button('選択を削除', self.remove_selected, row)
        self.clear_btn = self.button('一覧をクリア', self.clear_jobs, row)
        row.addStretch()
        self.button('使い方', self.help, row)
        layout.addLayout(row)
        split = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(split, 1)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.table = DropTable()
        self.table.setHorizontalHeaderLabels(['ファイル名', '種類', '長さ / サイズ', '切り出し範囲', '状態', '進捗'])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.dropped.connect(self.add_paths)
        self.table.itemSelectionChanged.connect(self.selection_changed)
        ll.addWidget(self.table, 1)
        self.preview_group = QGroupBox('選択した素材のプレビュー・トリミング（元ファイルは変更しません）')
        pl = QVBoxLayout(self.preview_group)
        self.preview = QStackedWidget()
        self.video = QVideoWidget()
        self.video.setMinimumHeight(150)
        self.image = QLabel('ファイルを選択してください')
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.addWidget(self.video)
        self.preview.addWidget(self.image)
        self.preview.setMaximumHeight(250)
        pl.addWidget(self.preview)
        self.player = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.audio_output.setVolume(.5)
        self.player.setAudioOutput(self.audio_output)
        self.player.setVideoOutput(self.video)
        self.player.positionChanged.connect(self.position_changed)
        self.player.errorOccurred.connect(lambda *a: self.preview_notice.setText('プレビュー非対応: ' + self.player.errorString() + '（時間入力で切り出せます）'))
        self.seek = QSlider(Qt.Orientation.Horizontal)
        self.seek.setRange(0, 0)
        self.seek.sliderMoved.connect(self.player.setPosition)
        pl.addWidget(self.seek)
        playback = QHBoxLayout()
        self.play_btn = self.button('再生 / 停止', self.toggle_play, playback)
        self.play_btn.setEnabled(False)
        self.position_label = QLabel('0.000 秒')
        playback.addWidget(self.position_label)
        playback.addStretch()
        pl.addLayout(playback)
        trim = QHBoxLayout()
        self.trim_start = QDoubleSpinBox()
        self.trim_end = QDoubleSpinBox()
        for w in (self.trim_start, self.trim_end):
            w.setRange(0, 8640000)
            w.setDecimals(3)
            w.setSuffix(' 秒')
            w.valueChanged.connect(self.trim_changed)
        trim.addWidget(QLabel('開始'))
        trim.addWidget(self.trim_start)
        trim.addWidget(QLabel('終了（0＝末尾）'))
        trim.addWidget(self.trim_end)
        pl.addLayout(trim)
        marks = QHBoxLayout()
        self.mark_start = self.button('再生位置を開始点に', lambda: self.trim_start.setValue(self.player.position() / 1000), marks)
        self.mark_end = self.button('再生位置を終了点に', lambda: self.trim_end.setValue(self.player.position() / 1000), marks)
        self.reset_trim = self.button('範囲をリセット', self.reset_range, marks)
        pl.addLayout(marks)
        self.trim_label = QLabel('切り出し長さ: —')
        pl.addWidget(self.trim_label)
        self.preview_notice = QLabel('プレビューできない形式も時間入力で変換できます。')
        self.preview_notice.setWordWrap(True)
        pl.addWidget(self.preview_notice)
        self.source_bitrate_label = QLabel('元のビットレート: —')
        self.source_bitrate_label.setWordWrap(True)
        pl.addWidget(self.source_bitrate_label)
        ll.addWidget(self.preview_group)
        split.addWidget(left)
        self.tabs = QTabWidget()
        split.addWidget(self.tabs)
        split.setSizes([760, 450])
        v = QWidget()
        vf = QFormLayout(v)
        vf.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        fmt = self.field(vf, 'video_format', '出力形式', combo(VIDEO_FORMATS))
        codec = self.field(vf, 'codec', '動画コーデック', combo(VIDEO_CODECS))
        device = self.field(vf, 'device', 'エンコード方式', combo(['自動', 'CPU', 'NVIDIA', 'Intel', 'AMD']))
        self.field(vf, 'decode_mode', 'デコード方式', combo(['自動', 'CPU', 'GPU']))
        concurrency = self.field(vf, 'parallel_jobs', '同時変換数（標準1）', spin(8, 1))
        concurrency.setMinimum(1)
        self.quality_note = QLabel()
        self.quality_note.setWordWrap(True)
        vf.addRow(self.quality_note)
        self.field(vf, 'extract_audio', '動画から音声だけを抽出', QCheckBox('音声タブの設定を使用'))
        preset = self.field(vf, 'size_preset', '解像度', combo(['元のサイズ', '2160p', '1440p', '1080p', '720p', '480p', 'カスタム']))
        self.field(vf, 'width', '幅（px / 0＝自動）', spin())
        self.field(vf, 'height', '高さ（px / 0＝自動）', spin())
        self.field(vf, 'keep_aspect', '縦横比', QCheckBox('比率を維持（枠内に収める）'))
        mode = self.field(vf, 'rate_mode', '画質・サイズの指定方法', combo(['品質', 'ビットレート', '指定サイズ（GB）']))
        target_size = QDoubleSpinBox()
        target_size.setRange(0.01, 999.99)
        target_size.setDecimals(2)
        target_size.setSingleStep(0.10)
        target_size.setValue(1.00)
        target_size.setSuffix(' GB')
        target_size.setToolTip('出力ファイル1本あたりの最大サイズです。実際の出力サイズを検査し、上限を超えた場合は最大3回再変換します。')
        self.field(vf, 'target_size_gb', '出力サイズ上限', target_size)
        q = self.field(vf, 'quality', '品質値（小さいほど高画質）', spin(51, 23))
        q.setToolTip('方式によって品質値の尺度は異なります。初期値23。')
        br = self.field(vf, 'video_kbps', '動画ビットレート（kbps）', spin(500000, 5000))
        br.setMinimum(1)
        self.field(vf, 'video_keep_bitrate', '動画ビットレート設定', QCheckBox('元のビットレートを使う（元の値）'))
        fps = QDoubleSpinBox()
        fps.setRange(0, 240)
        fps.setDecimals(3)
        self.field(vf, 'fps', 'フレームレート（fps / 0＝維持）', fps)
        fps.setToolTip('fpsは1秒あたりの表示枚数です。元の値を維持する場合は0。')
        br.setToolTip('kbpsは1秒あたりのデータ量（キロビット）です。大きいほど容量が増える傾向があります。')
        self.field(vf, 'mute', '音声', QCheckBox('音声を削除'))
        self.field(vf, 'video_audio', '音声（全トラック）', combo(['aac']))
        vabr = self.field(vf, 'video_audio_kbps', '動画の音声ビットレート（kbps）', spin(512, 192))
        vabr.setMinimum(16)
        self.field(vf, 'video_audio_keep_bitrate', '動画の音声ビットレート設定', QCheckBox('元のビットレートを使う（元の値）'))
        vabr.setToolTip('動画に含める音声のデータ量です。WAV・FLACには適用しません。')
        vf.addRow(QLabel('縦長動画ではプリセットの幅・高さを入れ替えます。\n元サイズ・正方画素・偶数サイズならサイズ補正を省略します。'))
        gpu_note = QLabel('GPU変換中の現在処理の一時停止は無効です。\n次のファイルを止める「キュー停止」は利用できます。\nデコード・サイズ変更などはCPUを使う場合があります。')
        gpu_note.setWordWrap(True)
        vf.addRow(gpu_note)
        self.tabs.addTab(scroll(v), '動画')
        a = QWidget()
        af = QFormLayout(a)
        audio_fmt = self.field(af, 'audio_format', '音声出力形式', combo(AUDIO_FORMATS))
        self.audio_codec_label = QLabel()
        af.addRow('出力コーデック（形式に応じて選択）', self.audio_codec_label)
        bitrate = self.field(af, 'audio_kbps', '音声ビットレート（kbps）', spin(512, 192))
        bitrate.setMinimum(16)
        self.field(af, 'audio_keep_bitrate', '音声ビットレート設定', QCheckBox('元のビットレートを使う（元の値）'))
        bitrate.setToolTip('音声の1秒あたりのデータ量（キロビット）です。WAV・FLACでは使用しません。')
        self.field(af, 'sample_rate', 'サンプルレート（Hz）', combo([0, 8000, 12000, 16000, 22050, 24000, 32000, 44100, 48000, 96000]))
        self.field(af, 'channels', 'チャンネル', combo(['元のまま', 'モノラル', 'ステレオ']))
        af.addRow(QLabel('Hz＝1秒あたりの音声サンプル数。\n0＝元の値を維持（必要時は変換）。\nWAVは16-bit PCM、FLACは可逆圧縮です。\nOpusは対応するサンプルレートを選択してください。\nビットレートは1秒あたりのデータ量です。'))
        self.tabs.addTab(scroll(a), '音声')
        i = QWidget()
        inf = QFormLayout(i)
        image_fmt = self.field(inf, 'image_format', '画像出力形式', combo(IMAGE_FORMATS))
        self.field(inf, 'image_width', '幅（px / 0＝元サイズ・自動）', spin(32768))
        self.field(inf, 'image_height', '高さ（px / 0＝元サイズ・自動）', spin(32768))
        self.field(inf, 'image_aspect', '縦横比', QCheckBox('比率を維持'))
        iq = self.field(inf, 'image_quality', 'JPEG / WebP品質（1〜100）', spin(100, 90))
        iq.setMinimum(1)
        bgrow = QWidget()
        bgl = QHBoxLayout(bgrow)
        bgl.setContentsMargins(0, 0, 0, 0)
        self.bg = QLineEdit('#ffffff')
        self.widgets['background'] = self.bg
        bgl.addWidget(self.bg)
        self.button('色を選ぶ', self.choose_color, bgl)
        inf.addRow('JPEG / BMPの透過背景色', bgrow)
        note = QLabel('EXIFの回転情報を適用します。\nアニメーションはPNG(APNG) / WebPで保持、\nTIFFでは全フレームをページとして保存します。\nJPEG / BMPへのアニメーション変換は非対応。\n複数ページTIFFはTIFFへの変換のみ対応。\n上限: 500フレーム・合計1億画素。')
        note.setWordWrap(True)
        inf.addRow(note)
        self.tabs.addTab(scroll(i), '画像')
        tools = QWidget()
        tf = QFormLayout(tools)
        for name in ('ffmpeg', 'ffprobe'):
            r = QWidget()
            rl = QHBoxLayout(r)
            rl.setContentsMargins(0, 0, 0, 0)
            entry = QLineEdit()
            entry.setPlaceholderText('空欄＝toolsフォルダー・PATHから自動検出')
            self.widgets[name] = entry
            rl.addWidget(entry)
            self.button('参照', lambda checked=False, n=name: self.choose_tool(n), rl)
            tf.addRow(name, r)
            entry.textChanged.connect(self.invalidate_caps)
        self.detect_btn = self.button('機能確認 / GPU試験', self.detect_capabilities)
        tf.addRow(self.detect_btn)
        self.cap_label = QLabel('機能を確認していません')
        self.cap_label.setWordWrap(True)
        tf.addRow(self.cap_label)
        self.cap_details = QPlainTextEdit()
        self.cap_details.setReadOnly(True)
        tf.addRow('エンコーダーと確認結果', self.cap_details)
        install_note = QLabel('FFmpegがない場合:\ntoolsにffmpeg.exeとffprobe.exeを配置してください。\n入手先と手順はREADMEを参照してください。')
        install_note.setWordWrap(True)
        tf.addRow(install_note)
        self.tabs.addTab(scroll(tools), 'ツール設定')
        output = QHBoxLayout()
        output.addWidget(QLabel('出力先'))
        self.output_dir = QLineEdit()
        self.output_dir.setPlaceholderText('空欄＝各素材の隣にconvertedフォルダー')
        self.widgets['output_dir'] = self.output_dir
        output.addWidget(self.output_dir, 1)
        self.output_choose = self.button('フォルダー選択', self.choose_output, output)
        self.same_folder = QCheckBox('素材と同じ場所')
        self.widgets['same_folder'] = self.same_folder
        self.same_folder.toggled.connect(lambda checked: self.output_dir.setEnabled(not checked))
        output.addWidget(self.same_folder)
        self.button('出力を開く', self.open_output, output)
        layout.addLayout(output)
        actions = QHBoxLayout()
        self.start_btn = self.button('変換開始', self.start_batch, actions)
        self.pause_btn = self.button('現在を一時停止', self.pause_current, actions)
        self.queue_btn = self.button('キュー停止', self.pause_queue, actions)
        self.cancel_btn = self.button('選択中の変換を中止', self.cancel_current, actions)
        self.cancel_all_btn = self.button('全体をキャンセル', lambda: self.batch and self.batch.control.cancel(True), actions)
        self.encoder_label = QLabel('エンコーダー: 待機')
        actions.addWidget(self.encoder_label)
        actions.addStretch()
        layout.addLayout(actions)
        self.total = QProgressBar()
        self.total.setFormat('キュー処理済み: %p%（失敗・中止を含む）')
        layout.addWidget(self.total)
        self.status_label = QLabel('ファイルを追加してください')
        layout.addWidget(self.status_label)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumHeight(100)
        self.log_view.setPlaceholderText('処理ログ・エラー詳細')
        self.log_view.document().setMaximumBlockCount(1500)
        layout.addWidget(self.log_view)
        log_row = QHBoxLayout()
        self.button('ログを保存', self.export_log, log_row)
        log_row.addStretch()
        layout.addLayout(log_row)
        for w in (fmt, codec, device, mode, audio_fmt, image_fmt):
            w.currentTextChanged.connect(self.update_options)
        target_size.valueChanged.connect(self.update_options)
        self.widgets['mute'].toggled.connect(self.update_options)
        self.widgets['extract_audio'].toggled.connect(self.update_options)
        self.widgets['video_audio'].currentTextChanged.connect(self.update_options)
        for key in ('video_keep_bitrate', 'video_audio_keep_bitrate', 'audio_keep_bitrate'):
            self.widgets[key].toggled.connect(self.update_options)
        preset.currentTextChanged.connect(self.preset_changed)
        self.set_running(False)
        self.set_trim_enabled(False)
        self.setStyleSheet('''
            QMainWindow { background: #f4f6fa; }
            QLabel#heading { font-size: 22px; font-weight: 600; color: #183455; }
            QPushButton { padding: 6px 10px; min-height: 20px; }
            QGroupBox { font-weight: 600; margin-top: 10px; padding-top: 10px; }
            QTableWidget, QPlainTextEdit { background: white; border: 1px solid #ccd6e4; }
            QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { min-height: 24px; }
            QProgressBar { border: 1px solid #ccd6e4; border-radius: 4px; text-align: center; }
            QProgressBar::chunk { background: #74b5e8; }
        ''')

    def invalidate_caps(self):
        self.checked_ffmpeg = ''
        self.cap_label.setText('ツール設定変更後は「機能確認」を実行してください')

    def append_log(self, text):
        self.log_view.appendPlainText(text)
        try:
            with self.log_path.open('a', encoding='utf-8') as f:
                f.write(text + '\n')
        except OSError:
            pass

    def read_settings(self):
        data = {}
        for key, w in self.widgets.items():
            if isinstance(w, QCheckBox):
                data[key] = w.isChecked()
            elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
                data[key] = w.value()
            elif isinstance(w, QComboBox):
                data[key] = w.currentText()
            else:
                data[key] = w.text().strip()
        if data.get('video_audio') == 'そのままコピー':
            data['video_audio'] = 'copy'
        data['sample_rate'] = int(data['sample_rate'])
        data['channels'] = self.widgets['channels'].currentIndex()
        return Settings.from_dict(data)

    def restore(self):
        data = asdict(Settings())
        try:
            saved = json.loads(self.config_path.read_text(encoding='utf-8'))
            if isinstance(saved, dict):
                data.update(saved)
        except (OSError, ValueError):
            pass
        for key, w in self.widgets.items():
            value = data.get(key)
            w.blockSignals(True)
            try:
                if isinstance(w, QCheckBox):
                    w.setChecked(bool(value))
                elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
                    w.setValue(float(value) if isinstance(w, QDoubleSpinBox) else int(value))
                elif isinstance(w, QComboBox):
                    if key == 'channels':
                        w.setCurrentIndex(int(value))
                    else:
                        w.setCurrentText('そのままコピー' if key == 'video_audio' and value == 'copy' else str(value))
                else:
                    w.setText(str(value or ''))
            except (TypeError, ValueError):
                pass
            finally:
                w.blockSignals(False)
        self.output_dir.setEnabled(not self.same_folder.isChecked())
        self.update_options()
        self.preset_changed()

    def save_settings(self):
        try:
            temporary = self.config_path.with_suffix('.tmp')
            temporary.write_text(json.dumps(asdict(self.read_settings()), ensure_ascii=False, indent=2), encoding='utf-8')
            temporary.replace(self.config_path)
        except OSError as exc:
            self.append_log('設定保存失敗: ' + str(exc))

    def choose_tool(self, name):
        path, _ = QFileDialog.getOpenFileName(self, name + 'を選択', '', '実行ファイル (*.exe);;すべて (*)')
        if path:
            self.widgets[name].setText(path)

    def choose_output(self):
        path = QFileDialog.getExistingDirectory(self, '出力フォルダー')
        if path:
            self.output_dir.setText(path)
            self.same_folder.setChecked(False)

    def choose_color(self):
        color = QColorDialog.getColor(QColor(self.bg.text()), self, '透過部分の背景色')
        if color.isValid():
            self.bg.setText(color.name())

    def choose_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, '動画・画像・音声を追加', '', 'メディアファイル (*.*)')
        self.add_paths(paths)

    def add_paths(self, paths):
        if self.busy():
            self.status_label.setText('処理中は追加できません。完了後に追加してください。')
            return
        known = {str(Path(j.path).resolve()).casefold() for j in self.jobs}
        selected = []
        for p in paths:
            path = Path(p)
            if (path.is_file() or path.is_dir()) and str(path.resolve()).casefold() not in known:
                selected.append(str(path.resolve()))
                known.add(str(path.resolve()).casefold())
        if not selected:
            return
        try:
            ffprobe = discover_tool('ffprobe', self.widgets['ffprobe'].text().strip())
        except ValueError:
            ffprobe = self.widgets['ffprobe'].text().strip() or 'ffprobe'
        self.scan = ScanThread(selected, ffprobe)
        self.scan.result.connect(self.add_job)
        self.scan.error.connect(self.scan_error)
        self.scan.finished.connect(self.scan_finished)
        self.status_label.setText('ファイル情報を調査中…')
        self.set_running(False, scanning=True)
        self.scan.start()

    def scan_error(self, path, error):
        self.append_log(path + '\n' + error)
        self.status_label.setText('追加できないファイルがあります。詳細ログを確認してください。')

    def scan_finished(self):
        self.set_running(False)
        self.status_label.setText(f'{len(self.jobs)}ファイル。共通設定を確認して変換開始してください。')
        if self.jobs and not self.table.selectedItems():
            self.table.selectRow(0)

    def add_job(self, job):
        if any(Path(j.path) == Path(job.path) for j in self.jobs):
            return
        self.jobs.append(job)
        row = self.table.rowCount()
        self.table.insertRow(row)
        for col in range(6):
            self.table.setItem(row, col, QTableWidgetItem())
        self.update_row(job)

    def update_row(self, job):
        row = next((i for i, j in enumerate(self.jobs) if j.uid == job.uid), -1)
        if row < 0:
            return
        duration = f'{job.duration:.3f}秒' if job.duration else '長さ不明' if job.kind != '画像' else ''
        size = f'{job.width}×{job.height}' if job.width else ''
        trim = '全体' if not job.start and not job.end else f'{job.start:.3f} → {job.end:.3f}' if job.end else f'{job.start:.3f} → 末尾'
        values = [Path(job.path).name, job.kind, ' / '.join(x for x in (duration, size) if x), trim, job.status, f'{job.progress}% ' + job.detail]
        for c, text in enumerate(values):
            self.table.item(row, c).setText(text)
            self.table.item(row, c).setToolTip(job.path if c == 0 else job.error or job.detail or job.output)
        self.table.resizeRowToContents(row)

    def choose_folder(self):
        path = QFileDialog.getExistingDirectory(self, 'フォルダーを追加（サブフォルダーも調査）')
        if path:
            self.add_paths([path])

    def move_selected(self, direction):
        if self.busy():
            return
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=direction > 0)
        if not rows:
            return
        if min(rows) + direction < 0 or max(rows) + direction >= len(self.jobs):
            return
        for row in rows:
            self.jobs[row], self.jobs[row + direction] = self.jobs[row + direction], self.jobs[row]
        self.table.clearSelection()
        for job in self.jobs:
            self.update_row(job)
        self.table.selectRow(rows[0] + direction)

    def retry_failed(self):
        self.start_batch(failed_only=True)

    def cancel_current(self):
        if not self.batch:
            return
        job = self.selected_job()
        if job and job.uid in self.batch.control.active:
            self.batch.control.cancel(uid=job.uid)
        elif len(self.batch.control.active) == 1:
            self.batch.control.cancel()
        else:
            self.status_label.setText('中止する変換中のファイルを一覧で選択してください。')

    def remove_selected(self):
        rows = sorted({index.row() for index in self.table.selectedIndexes()}, reverse=True)
        self.player.stop()
        for row in rows:
            self.table.removeRow(row)
            self.jobs.pop(row)
        self.selection_changed()

    def clear_jobs(self):
        self.player.stop()
        self.player.setSource(QUrl())
        self.table.setRowCount(0)
        self.jobs.clear()
        self.selection_changed()

    def selected_job(self):
        rows = sorted({index.row() for index in self.table.selectedIndexes()})
        return self.jobs[rows[0]] if rows and rows[0] < len(self.jobs) else None

    def set_trim_enabled(self, enabled):
        for w in (self.trim_start, self.trim_end, self.mark_start, self.mark_end, self.reset_trim):
            w.setEnabled(enabled)

    def selection_changed(self):
        job = self.selected_job()
        self.player.stop()
        self.loading_trim = True
        self.preview_notice.setText('プレビューできない形式も時間入力で変換できます。')
        if not job:
            self.source_bitrate_label.setText('元のビットレート: —')
            self.player.setSource(QUrl())
            self.preview.setCurrentWidget(self.image)
            self.image.clear()
            self.image.setText('ファイルを選択してください')
            self.set_trim_enabled(False)
            self.play_btn.setEnabled(False)
            self.loading_trim = False
            return
        def rate_text(rate):
            return f'{rate / 1000:.3f} kbps' if rate else '取得できません'
        self.source_bitrate_label.setText('元のビットレート: 画像は対象外' if job.kind == '画像' else
                                         '元のビットレート: ' +
                                         (f'動画 {rate_text(job.video_bps)} / ' if job.kind == '動画' else '') +
                                         (f'音声 {rate_text(job.audio_bps)}' if job.has_audio else '音声なし'))
        if job.kind == '動画':
            self.source_bitrate_label.setText(self.source_bitrate_label.text() + f'\n入力: {job.video_codec} / {job.pix_fmt} / {job.bit_depth}ビット / SAR {job.sar}' + (' / HDR（この版は変換未対応）' if job.hdr else ''))
        self.trim_start.setValue(job.start)
        self.trim_end.setValue(job.end)
        self.seek.setRange(0, min(2_147_483_647, round(job.duration * 1000)))
        self.seek.setValue(0)
        self.position_label.setText('0.000 秒')
        media = job.kind in ('動画', '音声')
        self.set_trim_enabled(media and not (self.batch and self.batch.isRunning()))
        self.play_btn.setEnabled(media)
        self.seek.setEnabled(media)
        if media:
            self.preview.setCurrentWidget(self.video if job.kind == '動画' else self.image)
            if job.kind == '音声':
                self.image.clear()
                self.image.setText('音声プレビュー')
            self.player.setSource(QUrl.fromLocalFile(job.path))
        else:
            self.player.setSource(QUrl())
            self.preview.setCurrentWidget(self.image)
            try:
                from PIL import Image, ImageOps
                from PIL.ImageQt import ImageQt
                with Image.open(job.path) as im:
                    im = ImageOps.exif_transpose(im).convert('RGBA')
                    im.thumbnail((600, 220))
                    self.image.setPixmap(QPixmap.fromImage(ImageQt(im)))
            except Exception:
                self.image.clear()
                self.image.setText('画像プレビュー非対応')
        self.loading_trim = False
        self.show_trim_length(job)

    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def position_changed(self, position):
        if not self.seek.isSliderDown():
            self.seek.setValue(position)
        self.position_label.setText(f'{position / 1000:.3f} 秒')

    def trim_changed(self):
        if self.loading_trim:
            return
        job = self.selected_job()
        if job and job.kind != '画像':
            job.start, job.end = self.trim_start.value(), self.trim_end.value()
            self.update_row(job)
            self.show_trim_length(job)

    def show_trim_length(self, job):
        try:
            length = trim_length(job) if job.kind != '画像' else 0
            self.trim_label.setText(f'切り出し長さ: {length:.3f} 秒' if length > 0 else '切り出し長さ: 不明 / 画像はトリミング対象外')
        except ValueError as exc:
            self.trim_label.setText(str(exc))

    def reset_range(self):
        self.trim_start.setValue(0)
        self.trim_end.setValue(0)

    def preset_changed(self):
        preset = self.widgets['size_preset'].currentText()
        sizes = {'元のサイズ': (0, 0), '2160p': (3840, 2160), '1440p': (2560, 1440), '1080p': (1920, 1080), '720p': (1280, 720), '480p': (854, 480)}
        if preset in sizes:
            w, h = sizes[preset]
            self.widgets['width'].setValue(w)
            self.widgets['height'].setValue(h)
        self.widgets['width'].setEnabled(preset == 'カスタム')
        self.widgets['height'].setEnabled(preset == 'カスタム')

    def refill_combo(self, widget, values):
        old = widget.currentText()
        if [widget.itemText(i) for i in range(widget.count())] == list(values):
            return
        widget.blockSignals(True)
        widget.clear()
        widget.addItems(list(values))
        if old in values:
            widget.setCurrentText(old)
        widget.blockSignals(False)

    def update_options(self, *args):
        fmt = self.widgets['video_format'].currentText()
        self.refill_combo(self.widgets['codec'], VIDEO_FORMATS[fmt])
        codec = self.widgets['codec']
        tested = bool(self.checked_ffmpeg)
        for i in range(codec.count()):
            name = codec.itemText(i)
            enabled = tested and any(pair[0] == name for pair in self.caps['video'].values())
            codec.model().item(i).setEnabled(enabled)
        if tested and codec.count() and not codec.model().item(codec.currentIndex()).isEnabled():
            for i in range(codec.count()):
                if codec.model().item(i).isEnabled():
                    codec.blockSignals(True)
                    codec.setCurrentIndex(i)
                    codec.blockSignals(False)
                    break
        name = codec.currentText()
        dev = self.widgets['device']
        for i in range(dev.count()):
            d = dev.itemText(i)
            enabled = tested and any(pair[0] == name and (d == '自動' or pair[1] == d) for pair in self.caps['video'].values())
            dev.model().item(i).setEnabled(enabled)
            dev.model().item(i).setToolTip('利用可能' if enabled else '試験に失敗、またはこのコーデックのエンコーダーなし。ツール設定の詳細を確認してください。')
        if tested and not dev.model().item(dev.currentIndex()).isEnabled():
            dev.blockSignals(True)
            dev.setCurrentIndex(0)
            dev.blockSignals(False)
        self.refill_combo(self.widgets['video_audio'], ['そのままコピー', *VIDEO_AUDIO[fmt]])
        audio = self.widgets['video_audio']
        for i in range(audio.count()):
            audio.model().item(i).setEnabled(tested and (audio.itemText(i) == 'そのままコピー' or audio.itemText(i) in self.caps['audio']))
        if tested and not audio.model().item(audio.currentIndex()).isEnabled():
            for i in range(audio.count()):
                if audio.model().item(i).isEnabled():
                    audio.setCurrentIndex(i)
                    break
        afmt = self.widgets['audio_format']
        for i in range(afmt.count()):
            afmt.model().item(i).setEnabled(tested and AUDIO_FORMATS[afmt.itemText(i)] in self.caps['audio'])
        if tested and not afmt.model().item(afmt.currentIndex()).isEnabled():
            for i in range(afmt.count()):
                if afmt.model().item(i).isEnabled():
                    afmt.blockSignals(True)
                    afmt.setCurrentIndex(i)
                    afmt.blockSignals(False)
                    break
        from engine import quality_args
        devices = {'AMD': '_amf', 'NVIDIA': '_nvenc', 'Intel': '_qsv'}
        suffix = devices.get(dev.currentText(), '')
        metric = 'AMF QP' if suffix == '_amf' else 'NVENC CQ' if suffix == '_nvenc' else 'QSV ICQ/global_quality' if suffix == '_qsv' else 'CPU CRF（自動選択では実行ログを確認）'
        self.quality_note.setText('品質の尺度: ' + metric + '。小さいほど高品質。方式間で同じ数値が同品質とは限りません。')
        rate_mode = self.widgets['rate_mode'].currentText()
        self.widgets['quality'].setEnabled(rate_mode == '品質')
        bitrate_mode = rate_mode == 'ビットレート'
        size_mode = rate_mode == '指定サイズ（GB）' and not self.widgets['extract_audio'].isChecked()
        self.widgets['video_keep_bitrate'].setEnabled(bitrate_mode)
        self.widgets['video_kbps'].setEnabled(bitrate_mode and not self.widgets['video_keep_bitrate'].isChecked())
        self.widgets['target_size_gb'].setEnabled(size_mode)
        if size_mode:
            self.quality_note.setText('出力サイズ上限: 1ファイルあたり ' + f"{self.widgets['target_size_gb'].value():.2f} GB。動画ビットレートを自動計算し、上限超過時は最大3回再変換します。画質は変換時間・容量に応じて変わります。")
        self.widgets['video_audio'].setEnabled(not self.widgets['mute'].isChecked() and not self.widgets['extract_audio'].isChecked())
        lossy_audio = self.widgets['audio_format'].currentText() not in ('wav', 'flac')
        video_uses_bitrate = not self.widgets['extract_audio'].isChecked() and not self.widgets['mute'].isChecked() and audio.currentText() not in ('そのままコピー', 'flac', 'pcm_s16le')
        self.widgets['audio_keep_bitrate'].setEnabled(lossy_audio)
        self.widgets['video_audio_keep_bitrate'].setEnabled(video_uses_bitrate)
        self.widgets['audio_kbps'].setEnabled(lossy_audio and not self.widgets['audio_keep_bitrate'].isChecked())
        self.widgets['video_audio_kbps'].setEnabled(video_uses_bitrate and not self.widgets['video_audio_keep_bitrate'].isChecked())
        self.audio_codec_label.setText(AUDIO_FORMATS.get(afmt.currentText(), '利用不可'))
        self.widgets['image_quality'].setEnabled(self.widgets['image_format'].currentText() in ('jpg', 'webp'))
        self.bg.setEnabled(self.widgets['image_format'].currentText() in ('jpg', 'bmp'))
        sr = self.widgets['sample_rate']
        for i in range(sr.count()):
            valid = self.widgets['audio_format'].currentText() != 'opus' or int(sr.itemText(i)) in (0, 8000, 16000, 24000, 48000, 12000)
            if afmt.currentText() == 'mp3' and int(sr.itemText(i)) > 48000:
                valid = False
            sr.model().item(i).setEnabled(valid)
        if not sr.model().item(sr.currentIndex()).isEnabled():
            sr.setCurrentIndex(0)

    def detect_capabilities(self):
        if self.busy():
            return
        try:
            ffmpeg = discover_tool('ffmpeg', self.widgets['ffmpeg'].text().strip())
        except ValueError as exc:
            self.cap_label.setText(str(exc))
            self.append_log(str(exc))
            return
        self.checked_ffmpeg = ''
        self.cap_thread = CapabilityThread(ffmpeg)
        self.cap_thread.message.connect(self.cap_label.setText)
        self.cap_thread.error.connect(self.cap_error)
        self.cap_thread.result.connect(lambda caps: self.cap_result(caps, ffmpeg))
        self.cap_thread.finished.connect(lambda: self.set_running(False))
        self.set_running(False, scanning=True)
        self.cap_thread.start()

    def cap_error(self, error):
        self.cap_label.setText(error)
        self.append_log(error)

    def cap_result(self, caps, ffmpeg):
        self.caps, self.checked_ffmpeg = caps, ffmpeg
        self.cap_label.setText(f'利用可能: 動画{len(caps["video"])}方式 / 音声{len(caps["audio"])}方式')
        lines = [f'使用するFFmpeg: {ffmpeg}', 'GPU試験: 1280×720 / 30fps / 8フレーム。AMDはNV12で試験します。',
                 'AMDのH.265方式はhevc_amfです。×の行の説明と詳細エラーを確認してください。']
        lines += [f'✓ {encoder}: {pair[0]} / {pair[1]}' for encoder, pair in caps['video'].items()]
        lines += [f'× {encoder}: {reason}' for encoder, reason in caps['reasons'].items()]
        lines += ['GPUデコード候補（入力ごとに追加試験）: ' + ', '.join(caps.get('hwaccels', [])), 'GPUフィルター候補: ' + ', '.join(f for f in caps.get('filters', []) if any(t in f for t in ('amf', 'cuda', 'qsv')))]
        self.cap_details.setPlainText('\n\n'.join(lines))
        self.append_log('[機能試験結果・実変換とは別]\n' + '\n\n'.join(lines))
        self.update_options()
        self.save_settings()

    def busy(self):
        return any(t and t.isRunning() for t in (self.batch, self.scan, self.cap_thread))

    def set_running(self, running, scanning=False):
        for w in (self.add_btn, self.remove_btn, self.clear_btn, self.folder_btn, self.up_btn, self.down_btn, self.retry_btn, self.start_btn, self.tabs, self.same_folder, self.output_choose):
            w.setEnabled(not running and not scanning)
        self.output_dir.setEnabled(not running and not scanning and not self.same_folder.isChecked())
        self.queue_btn.setEnabled(running)
        self.cancel_btn.setEnabled(running)
        self.cancel_all_btn.setEnabled(running)
        self.pause_btn.setEnabled(False)
        self.set_trim_enabled(not running and not scanning and bool(self.selected_job()) and self.selected_job().kind != '画像')
        if not running:
            self.pause_btn.setText('現在を一時停止')
            self.queue_btn.setText('キュー停止')

    def start_batch(self, checked=False, failed_only=False):
        if self.busy():
            return
        jobs = [j for j in self.jobs if (j.status == '失敗' if failed_only else j.status != '完了')]
        if not jobs:
            QMessageBox.information(self, '変換', '変換するファイルを追加してください。完了したファイルはスキップします。')
            return
        settings = self.read_settings()
        try:
            from PIL import ImageColor
            ImageColor.getrgb(settings.background)
            for job in jobs:
                if job.kind != '画像':
                    trim_length(job)
                    ffmpeg = discover_tool('ffmpeg', settings.ffmpeg)
                    if ffmpeg != self.checked_ffmpeg:
                        raise ValueError('ツール設定で「機能確認 / GPU試験」を実行してください。')
                    if job.kind == '動画' and not settings.extract_audio:
                        select_encoder(settings, self.caps)
                        if settings.size_preset == 'カスタム' and any(x and (x < 2 or x % 2) for x in (settings.width, settings.height)):
                            raise ValueError('動画の幅・高さは2以上の偶数、または0にしてください。')
                        if settings.rate_mode == '指定サイズ（GB）':
                            if not (0 < settings.target_size_gb < 1000):
                                raise ValueError('出力サイズ上限は0より大きく999.99 GB以下で指定してください。')
                            if job.has_audio and not settings.mute and settings.video_audio in ('copy', 'flac', 'pcm_s16le'):
                                raise ValueError('指定サイズモードでは音声コピー・FLAC・PCMを使えません。AAC/Opusなどの圧縮音声を選ぶか、「音声を削除」を有効にしてください。')
        except Exception as exc:
            QMessageBox.warning(self, '設定を確認してください', str(exc))
            return
        self.save_settings()
        self.player.pause()
        self.total.setValue(0)
        for job in jobs:
            job.status, job.progress, job.error = '待機', 0, ''
            self.update_row(job)
        self.batch = BatchThread(jobs, copy.deepcopy(settings), copy.deepcopy(self.caps))
        self.batch.changed.connect(self.job_changed)
        self.batch.total.connect(self.total.setValue)
        self.batch.log.connect(self.append_log)
        self.batch.active_encoder.connect(self.encoder_changed)
        self.batch.request_retry.connect(self.ask_cpu_retry)
        self.batch.finished.connect(self.batch_finished)
        self.set_running(True)
        self.status_label.setText('変換中…')
        self.batch.start()

    def job_changed(self, uid, status, percent, detail):
        job = next((j for j in self.jobs if j.uid == uid), None)
        if not job:
            return
        job.status, job.progress = status, percent
        if status == '変換中':
            job.detail = detail
        if status == '失敗':
            job.error = detail
            self.status_label.setText(Path(job.path).name + ' — 変換に失敗しました。詳細ログを確認してください。')
            self.append_log('変換失敗: ' + Path(job.path).name + '\n' + detail)
        if status == '完了':
            self.last_output_dir = str(Path(detail).parent)
        self.update_row(job)
        if status == '変換中':
            if self.batch and self.batch.control.process_paused:
                self.status_label.setText(Path(job.path).name + ' — 一時停止中')
            else:
                self.status_label.setText(Path(job.path).name + ' — ' + detail)

    def encoder_changed(self, encoder, can_pause):
        self.encoder_label.setText('エンコーダー: ' + encoder)
        # Process creation follows this signal; guard in Control.suspend handles the brief gap.
        self.pause_btn.setEnabled(can_pause and encoder != '待機')
        self.pause_btn.setText('現在を一時停止')
        self.pause_btn.setToolTip('CPUのFFmpegプロセスを中断・再開します。GPU・画像・情報取得中は非対応。')

    def ask_cpu_retry(self, request):
        control = request['control']
        if control.cancel_current.is_set() or control.cancel_all.is_set():
            request['reply'].set()
            return
        box = QMessageBox(self)
        box.setWindowTitle('GPU変換に失敗しました')
        box.setText('このファイルをCPUで最初から再試行しますか？')
        box.setDetailedText(request['detail'])
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.No)
        timer = QTimer(box)
        timer.timeout.connect(lambda: box.reject() if control.cancel_current.is_set() or control.cancel_all.is_set() else None)
        timer.start(100)
        try:
            request['allow'] = box.exec() == QMessageBox.StandardButton.Yes
        finally:
            timer.stop()
            request['reply'].set()

    def pause_current(self):
        if not self.batch or not self.batch.isRunning():
            return
        try:
            if self.batch.control.process_paused:
                self.batch.control.resume()
                self.pause_btn.setText('現在を一時停止')
                self.status_label.setText('現在の変換を再開しました')
            else:
                self.batch.control.suspend()
                self.pause_btn.setText('現在を再開')
                self.status_label.setText('現在の変換を一時停止中（処理位置を維持）')
        except Exception as exc:
            QMessageBox.warning(self, '一時停止', str(exc))

    def pause_queue(self):
        if not self.batch:
            return
        if self.batch.control.queue_paused.is_set():
            self.batch.control.queue_paused.clear()
            self.queue_btn.setText('キュー停止')
            self.status_label.setText('キューを再開しました')
        else:
            self.batch.control.queue_paused.set()
            self.queue_btn.setText('キュー再開')
            self.status_label.setText('キュー停止: 現在のファイルは続行し、次のファイルの開始を止めます')

    def batch_finished(self):
        self.set_running(False)
        self.encoder_label.setText('エンコーダー: 待機')
        counts = {s: sum(j.status == s for j in self.batch.jobs) for s in ('完了', '失敗', '中止')}
        self.status_label.setText('処理終了: ' + ' / '.join(f'{s} {n}件' for s, n in counts.items()))
        self.append_log(self.status_label.text())

    def open_output(self):
        path = self.last_output_dir or self.output_dir.text().strip()
        if not path:
            job = self.selected_job()
            if job:
                path = str(Path(job.path).parent if self.same_folder.isChecked() else Path(job.path).parent / 'converted')
        if path and Path(path).is_dir():
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            QMessageBox.information(self, '出力先', '出力フォルダーはまだ作成されていません。')

    def export_log(self):
        path, _ = QFileDialog.getSaveFileName(self, 'ログを保存', 'conversion.log', 'ログ (*.log)')
        if path:
            try:
                import shutil
                shutil.copyfile(self.log_path, path)
            except OSError as exc:
                QMessageBox.warning(self, 'ログ保存', str(exc))

    def help(self):
        path = ROOT / 'README.md'
        if path.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            QMessageBox.information(self, '使い方', '追加 → 設定 → 必要ならトリミング → 変換開始。\nCPU変換は現在処理の一時停止に対応。GPU・画像はキュー停止を使ってください。')

    def closeEvent(self, event):
        if self.busy():
            answer = QMessageBox.question(self, '処理中です', '処理を中止して終了しますか？',
                                          QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                          QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.status_label.setText('処理を終了しています…')
            if self.batch and self.batch.isRunning():
                self.batch.control.cancel(True)
                self.batch.reply.set()
            if self.scan and self.scan.isRunning():
                self.scan.requestInterruption()
                self.scan.control.cancel(True)
            if self.cap_thread and self.cap_thread.isRunning():
                self.cap_thread.stop_event.set()
                self.cap_thread.control.cancel(True)
            for t in (self.batch, self.scan, self.cap_thread):
                if t and t.isRunning() and not t.wait(10000):
                    QMessageBox.information(self, '終了待機', '処理の終了を待っています。少し待ってからもう一度閉じてください。')
                    event.ignore()
                    return
        self.player.stop()
        self.save_settings()
        event.accept()


def main():
    app = QApplication(sys.argv)
    if os.name == 'nt':
        app.setFont(QFont('Yu Gothic UI', 9))
    app.setOrganizationName('LocalMediaTools')
    app.setApplicationName('MediaConverter')
    window = Window()
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
