@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo setup.batを先に実行してください。
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pytest -q tests
set "MC_TEST_EXIT=%errorlevel%"
pause
exit /b %MC_TEST_EXIT%
