import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine import (Settings, Control, Cancelled, checked_process, convert_job,
                    discover_tool, probe_job, build_command)


@pytest.mark.parametrize('fmt', ['png', 'webp', 'tiff'])
def test_animation_preserves_all_frames_and_timing(tmp_path, fmt):
    src = tmp_path / '動く 画像.gif'
    frames = [Image.new('RGBA', (20, 30), c) for c in ['red', 'green', 'blue']]
    frames[0].save(src, save_all=True, append_images=frames[1:], duration=[100, 200, 300], loop=2)
    result = convert_job(probe_job(src, ''), Settings(output_dir=str(tmp_path), image_format=fmt,
                         image_width=10), {}, Control())
    with Image.open(result) as im:
        assert im.n_frames == 3
        times = []
        for n in range(im.n_frames):
            im.seek(n)
            assert im.size == (10, 15)
            im.load()
            times.append(im.info.get('duration'))
        if fmt != 'tiff':
            assert times == [100, 200, 300]
            assert im.info['loop'] == 2


def test_apng_poster_and_multipage_tiff(tmp_path):
    poster = tmp_path / 'poster.png'
    frames = [Image.new('RGBA', (10, 12), c) for c in ['white', 'red', 'blue']]
    frames[0].save(poster, save_all=True, append_images=frames[1:], default_image=True,
                   duration=[100, 200], loop=1)
    for fmt, count in [('png', 3), ('webp', 2)]:
        out = convert_job(probe_job(poster, ''), Settings(output_dir=str(tmp_path), image_format=fmt), {}, Control())
        with Image.open(out) as im:
            assert im.n_frames == count
            im.seek(count - 1)
            im.load()
            assert im.info['duration'] == 200
    src = tmp_path / 'pages.tiff'
    frames[0].save(src, save_all=True, append_images=frames[1:])
    out = convert_job(probe_job(src, ''), Settings(output_dir=str(tmp_path), image_format='tiff'), {}, Control())
    with Image.open(out) as im:
        assert im.n_frames == 3
    with pytest.raises(ValueError, match='複数ページ'):
        convert_job(probe_job(src, ''), Settings(output_dir=str(tmp_path), image_format='png'), {}, Control())


def test_non_square_pixels_and_rotated_video(tmp_path):
    ffmpeg, ffprobe = discover_tool('ffmpeg'), discover_tool('ffprobe')
    source = tmp_path / '横比率.mp4'
    subprocess.run([ffmpeg, '-v', 'error', '-f', 'lavfi', '-i', 'color=size=120x120:rate=10',
                    '-t', '0.5', '-vf', 'setsar=2', '-c:v', 'libx264', '-threads', '2', str(source)], check=True)
    job = probe_job(source, ffprobe)
    assert (job.width, job.height) == (240, 120)
    caps = {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac']}
    out = convert_job(job, Settings(output_dir=str(tmp_path), device='CPU'), caps, Control())
    result = probe_job(out, ffprobe)
    assert (result.width, result.height) == (240, 120)
    rotated = tmp_path / '回転.mp4'
    subprocess.run([ffmpeg, '-v', 'error', '-display_rotation', '90', '-i', str(out),
                    '-c', 'copy', str(rotated)], check=True)
    job = probe_job(rotated, ffprobe)
    assert (job.width, job.height) == (120, 240)
    out = convert_job(job, Settings(output_dir=str(tmp_path), device='CPU', size_preset='480p',
                      width=854, height=480), caps, Control())
    result = probe_job(out, ffprobe)
    assert result.height > result.width and result.width <= 480 and result.height <= 854


def test_unknown_pixel_aspect_does_not_collapse_width(tmp_path):
    source = tmp_path / 'unknown-sar.mkv'
    subprocess.run([discover_tool('ffmpeg'), '-v', 'error', '-f', 'lavfi', '-i',
                    'color=size=160x120:rate=10', '-t', '0.4', '-vf', 'setsar=0',
                    '-c:v', 'libx264', '-threads', '2', str(source)], check=True)
    job = probe_job(source, discover_tool('ffprobe'))
    out = convert_job(job, Settings(output_dir=str(tmp_path), device='CPU'),
                      {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac']}, Control())
    result = probe_job(out, discover_tool('ffprobe'))
    assert (result.width, result.height) == (160, 120)


def test_cancel_capability_child_reaps_process():
    control = Control()
    failures = []
    def execute():
        try:
            checked_process([sys.executable, '-c', 'import time; time.sleep(30)'], 15, control)
        except Exception as exc:
            failures.append(exc)
    worker = threading.Thread(target=execute)
    worker.start()
    deadline = time.monotonic() + 3
    while control.proc is None and time.monotonic() < deadline:
        time.sleep(.01)
    child = control.proc
    assert child is not None
    control.cancel(True)
    worker.join(3)
    assert not worker.is_alive() and isinstance(failures[0], Cancelled)
    assert child.poll() is not None


def test_audio_settings_independent_and_meaningless_fields_disabled(tmp_path, monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from app import Window
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window, 'detect_capabilities', lambda self: None)
    w = Window()
    w.widgets['audio_format'].setCurrentText('flac')
    w.widgets['mute'].setChecked(False)
    w.widgets['extract_audio'].setChecked(False)
    w.widgets['video_format'].setCurrentText('mp4')
    assert not w.widgets['audio_kbps'].isEnabled()
    assert w.widgets['video_audio_kbps'].isEnabled()
    w.widgets['mute'].setChecked(True)
    assert not w.widgets['video_audio_kbps'].isEnabled()
    w.widgets['audio_format'].setCurrentText('mp3')
    assert not w.widgets['sample_rate'].model().item(w.widgets['sample_rate'].findText('96000')).isEnabled()
    w.close()
    app.processEvents()


@pytest.mark.parametrize('cancel_all', [False, True])
def test_batch_current_cancel_and_all_cancel(tmp_path, monkeypatch, cancel_all):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from app import BatchThread
    import engine
    app = QApplication.instance() or QApplication([])
    source = tmp_path / '先頭 動画.mp4'
    subprocess.run([discover_tool('ffmpeg'), '-v', 'error', '-f', 'lavfi', '-i',
                    'color=size=128x128:rate=10', '-t', '3', '-c:v', 'libx264',
                    '-threads', '2', str(source)], check=True)
    image = tmp_path / '次の 画像.png'
    Image.new('RGB', (10, 20), 'blue').save(image)
    jobs = [probe_job(source, discover_tool('ffprobe')), probe_job(image, '')]
    original = engine.build_command
    def slow(*args, **kwargs):
        cmd = original(*args, **kwargs)
        cmd.insert(cmd.index('-i'), '-re')
        return cmd
    monkeypatch.setattr(engine, 'build_command', slow)
    batch = BatchThread(jobs, Settings(device='CPU', output_dir=str(tmp_path / 'out')),
                        {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac']})
    batch.start()
    deadline = time.monotonic() + 4
    while batch.control.proc is None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.01)
    assert batch.control.proc is not None
    child = batch.control.proc
    batch.control.cancel(cancel_all)
    assert batch.wait(4000)
    assert child.poll() is not None and jobs[0].status == '中止'
    assert jobs[1].status == ('中止' if cancel_all else '完了')
    assert bool(jobs[1].output) is (not cancel_all)
    assert not list((tmp_path / 'out').glob('*.part*'))


def test_gui_close_stops_capability_trial(monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication, QMessageBox
    from app import Window, CapabilityThread
    import app as gui
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window, 'detect_capabilities', lambda self: None)
    monkeypatch.setattr(QMessageBox, 'question', lambda *a, **k: QMessageBox.StandardButton.Yes)
    def long_trial(ffmpeg, callback, stop, control):
        checked_process([sys.executable, '-c', 'import time; time.sleep(30)'], 15, control)
    monkeypatch.setattr(gui, 'check_capabilities', long_trial)
    w = Window()
    w.cap_thread = CapabilityThread('unused')
    w.cap_thread.start()
    deadline = time.monotonic() + 4
    while w.cap_thread.control.proc is None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.01)
    child = w.cap_thread.control.proc
    assert child is not None
    w.close()
    assert not w.cap_thread.isRunning() and child.poll() is not None
    app.processEvents()


def test_mixed_batch_queue_pause_then_resume(tmp_path, monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from app import BatchThread
    import app as gui
    app = QApplication.instance() or QApplication([])
    source = tmp_path / '動画 日本語.mp4'
    audio = tmp_path / '音声 日本語.wav'
    image = tmp_path / '画像 日本語.png'
    ffmpeg, ffprobe = discover_tool('ffmpeg'), discover_tool('ffprobe')
    subprocess.run([ffmpeg, '-v', 'error', '-f', 'lavfi', '-i', 'color=size=128x128:rate=10',
                    '-f', 'lavfi', '-i', 'sine=frequency=440', '-t', '0.6', '-c:v', 'libx264',
                    '-threads', '2', '-c:a', 'aac', str(source)], check=True)
    subprocess.run([ffmpeg, '-v', 'error', '-i', str(source), '-vn', str(audio)], check=True)
    Image.new('RGB', (20, 30), 'red').save(image)
    jobs = [probe_job(p, ffprobe) for p in [source, audio, image]]
    source_bytes = [Path(j.path).read_bytes() for j in jobs]
    original = gui.convert_job
    first_done = threading.Event()
    def convert_and_pause(job, settings, caps, control, *args, **kwargs):
        output = original(job, settings, caps, control, *args, **kwargs)
        if job.uid == jobs[0].uid:
            control.queue_paused.set()
            first_done.set()
        return output
    monkeypatch.setattr(gui, 'convert_job', convert_and_pause)
    batch = BatchThread(jobs, Settings(device='CPU', output_dir=str(tmp_path / '変換 結果')),
                        {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac', 'libmp3lame']})
    batch.start()
    assert first_done.wait(4)
    time.sleep(.15)
    assert batch.isRunning() and jobs[1].status == '待機' and not jobs[1].output
    batch.control.queue_paused.clear()
    assert batch.wait(4000)
    assert all(j.status == '完了' and Path(j.output).exists() for j in jobs)
    assert [Path(j.path).read_bytes() for j in jobs] == source_bytes
    assert not list((tmp_path / '変換 結果').glob('*.part*'))
    app.processEvents()
