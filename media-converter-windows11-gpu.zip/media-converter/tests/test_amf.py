"""Driver-dependent cases are simulated; these do not prove real AMD execution."""
import sys
from pathlib import Path
import subprocess

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine
from engine import Settings, Job, check_capabilities, build_command


def fake_ffmpeg(monkeypatch, trial_error=None, listed=True):
    calls = []
    def run(args, timeout, control):
        calls.append((args, timeout))
        if '-encoders' in args:
            listing = b' V..... hevc_amf AMD HEVC\n A..... aac AAC\n' if listed else b' A..... aac AAC\n'
            return subprocess.CompletedProcess(args, 0, listing, b'')
        if '-hwaccels' in args or '-filters' in args or '-h' in args:
            return subprocess.CompletedProcess(args, 0, b'', b'')
        # Emulate an encoder that rejects tiny frames but accepts standard 720p.
        source = args[args.index('-i') + 1]
        size = source.split('size=')[1].split(':')[0]
        w, h = [int(x) for x in size.split('x')]
        error = trial_error or (b'AMF_NOT_SUPPORTED: resolution too small' if w < 256 or h < 256 else b'')
        return subprocess.CompletedProcess(args, 1 if error else 0, b'', error)
    monkeypatch.setattr(engine, 'checked_process', run)
    return calls


def test_amf_standard_size_trial_allows_hevc_and_amd_selection(monkeypatch):
    calls = fake_ffmpeg(monkeypatch)
    caps = check_capabilities('mock-ffmpeg')
    assert caps['video']['hevc_amf'] == ('H.265', 'AMD')
    assert engine.select_encoder(Settings(codec='H.265', device='AMD'), caps) == ('hevc_amf', 'AMD')
    trial, timeout = next((args, timeout) for args, timeout in calls if '-frames:v' in args)
    assert trial[trial.index('-pix_fmt') + 1] == 'nv12'
    assert timeout == 15 and trial[trial.index('-frames:v') + 1] == '8'


def test_missing_amf_build_remains_disabled(monkeypatch):
    fake_ffmpeg(monkeypatch, listed=False)
    caps = check_capabilities('mock-ffmpeg')
    assert 'hevc_amf' not in caps['video']
    assert 'このFFmpegに含まれていません' in caps['reasons']['hevc_amf']
    with pytest.raises(ValueError):
        engine.select_encoder(Settings(codec='H.265', device='AMD'), caps)


def test_amf_driver_failure_remains_disabled_with_diagnostic(monkeypatch):
    fake_ffmpeg(monkeypatch, trial_error=b'AMF failed: Cannot load amfrt64.dll')
    caps = check_capabilities('mock-ffmpeg')
    assert 'hevc_amf' not in caps['video']
    assert 'Adrenalin' in caps['reasons']['hevc_amf']
    assert 'Cannot load amfrt64.dll' in caps['reasons']['hevc_amf']


@pytest.mark.parametrize('mode', ['品質', 'ビットレート'])
def test_amf_real_conversion_command_uses_nv12(monkeypatch, tmp_path, mode):
    monkeypatch.setattr(engine, 'discover_tool', lambda *args: 'ffmpeg.exe')
    job = Job(str(tmp_path / '元動画.mp4'), kind='動画', duration=3, width=1920, height=1080)
    command = build_command(Settings(codec='H.265', device='AMD', rate_mode=mode),
                            job, tmp_path / 'test.part.mp4', 'hevc_amf')
    assert command[command.index('-c:v') + 1] == 'hevc_amf'
    assert command[command.index('-pix_fmt') + 1] == 'nv12'
    if mode == '品質':
        assert command[command.index('-rc') + 1] == 'cqp'
        assert command[command.index('-usage') + 1] == 'transcoding'
    else:
        assert command[command.index('-b:v') + 1] == '5000000'
