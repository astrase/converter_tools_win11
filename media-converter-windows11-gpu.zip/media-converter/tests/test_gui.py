import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import sys
from pathlib import Path
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from app import Window, BatchThread
from engine import Settings, Job
from PIL import Image


def test_gui_and_batch_failure_continue(tmp_path,monkeypatch):
    app=QApplication.instance() or QApplication([])
    app.setApplicationName('MediaConverterTest')
    monkeypatch.setattr(Window,'detect_capabilities',lambda s:None)
    w=Window()
    w.show()
    app.processEvents()
    assert w.tabs.count()==4
    p=tmp_path/'画像 日本語.png'
    Image.new('RGB',(20,30),'red').save(p)
    w.add_paths([str(p)])
    deadline=time.time()+5
    while w.scan.isRunning() and time.time()<deadline:
        app.processEvents()
        time.sleep(.01)
    app.processEvents()
    assert len(w.jobs)==1
    w.table.selectRow(0)
    app.processEvents()
    assert not w.trim_start.isEnabled()
    w.widgets['video_format'].setCurrentText('webm')
    assert [w.widgets['codec'].itemText(i) for i in range(w.widgets['codec'].count())] == ['VP9','AV1']
    w.widgets['audio_format'].setCurrentText('opus')
    sr=w.widgets['sample_rate']
    assert not sr.model().item(sr.findText('44100')).isEnabled()
    settings=Settings(output_dir=str(tmp_path/'out'))
    bad=Job(str(tmp_path/'missing.png'),kind='画像')
    good=w.jobs[0]
    batch=BatchThread([bad,good],settings,{})
    changes=[]
    batch.changed.connect(lambda *args: changes.append(args))
    batch.start()
    deadline=time.time()+5
    while batch.isRunning() and time.time()<deadline:
        app.processEvents()
        time.sleep(.01)
    app.processEvents()
    assert any(x[0]==bad.uid and x[1]=='失敗' for x in changes)
    assert any(x[0]==good.uid and x[1]=='完了' for x in changes)
    assert Path(good.output).exists()
    w.close()
    app.processEvents()


def test_gui_close_terminates_ffmpeg(tmp_path,monkeypatch):
    import subprocess
    import engine
    from PySide6.QtWidgets import QMessageBox
    from engine import probe_job, discover_tool
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window,'detect_capabilities',lambda self:None)
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**kw: QMessageBox.StandardButton.Yes)
    source=tmp_path/'終了確認 素材.mp4'
    subprocess.run([discover_tool('ffmpeg'),'-v','error','-f','lavfi','-i','color=size=128x128:rate=10','-t','5','-c:v','libx264','-threads','2',str(source)],check=True)
    original=engine.build_command
    def slow(*a,**kw):
        args=original(*a,**kw)
        args.insert(args.index('-i'),'-re')
        return args
    monkeypatch.setattr(engine,'build_command',slow)
    w=Window()
    w.show()
    w.add_job(probe_job(source,discover_tool('ffprobe')))
    w.widgets['output_dir'].setText(str(tmp_path/'out'))
    w.widgets['video_format'].setCurrentText('mp4')
    w.widgets['codec'].setCurrentText('H.264')
    w.widgets['device'].setCurrentText('CPU')
    w.widgets['size_preset'].setCurrentText('元のサイズ')
    w.widgets['extract_audio'].setChecked(False)
    w.widgets['same_folder'].setChecked(False)
    w.widgets['ffmpeg'].setText('')
    w.checked_ffmpeg=discover_tool('ffmpeg')
    w.caps={'video':{'libx264':('H.264','CPU')},'audio':['aac'],'reasons':{}}
    w.start_batch()
    deadline=time.time()+5
    while w.batch.control.proc is None and time.time()<deadline:
        app.processEvents()
        time.sleep(.01)
    child=w.batch.control.proc
    assert child is not None
    w.close()
    app.processEvents()
    assert not w.batch.isRunning()
    assert child.poll() is not None
    assert not list((tmp_path/'out').glob('*.part*'))
    assert not list((tmp_path/'out').glob('*_converted*'))
