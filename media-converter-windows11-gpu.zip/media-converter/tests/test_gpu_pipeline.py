"""GPU command paths are simulated; CPU conversions below execute real FFmpeg."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine
import gpu_pipeline
from engine import Settings, Job, Control, Cancelled, build_command, convert_job, probe_job, discover_tool
from gpu_pipeline import Pipeline, candidates, input_depth, validate_video
from batch_queue import QueueControl, run_queue


@pytest.mark.parametrize('fmt,depth', [('yuv420p',8), ('yuv420p10le',10), ('p010le',10), ('yuv444p12le',12), ('mystery',0)])
def test_depth(fmt, depth):
    assert input_depth({'pix_fmt':fmt}) == depth


def test_no_filter_for_original_1078_and_non_square_correction(monkeypatch):
    monkeypatch.setattr(engine,'discover_tool',lambda *a:'ffmpeg')
    j=Job('input.mp4',kind='動画',width=1920,height=1078,video_codec='h264')
    args=build_command(Settings(),j,Path('out.mp4'),'hevc_amf')
    assert '-vf' not in args
    j.sar='4:3'
    assert '-vf' in build_command(Settings(),j,Path('out.mp4'),'hevc_amf')


def test_gpu_input_options_order_and_no_cpu_filter(monkeypatch):
    monkeypatch.setattr(engine,'discover_tool',lambda *a:'ffmpeg')
    j=Job('input.mp4',kind='動画',width=1920,height=1078,video_codec='h264')
    monkeypatch.setattr(gpu_pipeline,'IS_WINDOWS',True)
    route=candidates(Settings(decode_mode='GPU'),j,'hevc_amf',{'hwaccels':['d3d11va']},'')[0]
    args=build_command(Settings(codec='H.265'),j,Path('out.mp4'),'hevc_amf',route)
    assert args.index('-hwaccel') < args.index('-i')
    assert args[args.index('-hwaccel_output_format')+1]=='d3d11'
    assert '-vf' not in args and '-pix_fmt' not in args


def test_native_amf_gpu_scaling_preferred(monkeypatch):
    j=Job('input.mp4',kind='動画',width=1920,height=1080,video_codec='h264')
    s=Settings(width=1280,height=720)
    routes=candidates(s,j,'hevc_amf',{'hwaccels':['amf'],'filters':['vpp_amf']},engine.scale_filter(s,j))
    assert routes[0].filters=='vpp_amf=w=1280:h=720:format=nv12'
    assert routes[0].hardware_frames
    assert routes[-1].name=='CPU'


def test_hdr_and_10bit_refuse_silent_loss():
    j=Job('input.mp4',kind='動画',bit_depth=10)
    with pytest.raises(ValueError,match='10ビット'):
        validate_video(Settings(),j,'libx264')
    with pytest.raises(ValueError,match='10ビット対応'):
        validate_video(Settings(codec='H.265'),j,'hevc_amf',{})
    validate_video(Settings(codec='H.265'),j,'hevc_amf',{'pixel_formats':{'hevc_amf':['p010le']}})
    j.hdr=True
    with pytest.raises(ValueError,match='HDR'):
        validate_video(Settings(codec='H.265'),j,'libx265')


def test_audio_copy_validation_and_all_tracks(monkeypatch):
    monkeypatch.setattr(engine,'discover_tool',lambda *a:'ffmpeg')
    j=Job('input.mkv',kind='動画',width=128,height=128,has_audio=True,audio_codecs=['aac','aac'])
    s=Settings(video_audio='copy')
    args=build_command(s,j,Path('out.mp4'),'libx264')
    assert '0:a?' in args and args[args.index('-c:a')+1]=='copy' and '-b:a' not in args
    j.audio_codecs=['pcm_s16le']
    with pytest.raises(ValueError,match='音声コピー'):
        build_command(s,j,Path('out.mp4'),'libx264')
    s.mute=True
    args=build_command(s,j,Path('out.mp4'),'libx264')
    assert '-an' in args and '-c:a' not in args


def test_gpu_trial_fail_auto_decoder_falls_back_but_gpu_only_stops(monkeypatch,tmp_path):
    monkeypatch.setattr(engine,'discover_tool',lambda *a:'ffmpeg')
    j=Job('input.mp4',kind='動画',width=128,height=128,video_codec='h264')
    caps={'hwaccels':['amf']}
    monkeypatch.setattr(engine,'checked_process',lambda *a:subprocess.CompletedProcess(a[0],1,b'',b'no device'))
    logs=[]
    route=engine.prepare_pipeline(Settings(),j,tmp_path/'out.mp4','hevc_amf',caps,Control(),logs.append)
    assert route.name=='CPU' and any('no device' in line for line in logs)
    with pytest.raises(RuntimeError):
        engine.prepare_pipeline(Settings(decode_mode='GPU'),j,tmp_path/'out.mp4','hevc_amf',caps,Control(),logs.append)


@pytest.fixture
def source(tmp_path):
    p=tmp_path/'日本語 & 入力.mp4'
    subprocess.run([discover_tool('ffmpeg'),'-v','error','-f','lavfi','-i','testsrc2=size=128x96:rate=10','-f','lavfi','-i','sine=frequency=440','-t','1','-c:v','libx264','-threads','2','-c:a','aac',str(p)],check=True)
    return probe_job(p,discover_tool('ffprobe'))


def test_actual_audio_copy_and_mute_no_clobber(source,tmp_path):
    caps={'video':{'libx264':('H.264','CPU')},'audio':['aac']}
    original=Path(source.path).read_bytes()
    s=Settings(device='CPU',decode_mode='CPU',video_audio='copy',output_dir=str(tmp_path/'out'))
    out=convert_job(source,s,caps,Control())
    assert probe_job(out,discover_tool('ffprobe')).has_audio
    s.mute=True
    out2=convert_job(source,s,caps,Control())
    assert out != out2 and not probe_job(out2,discover_tool('ffprobe')).has_audio
    assert Path(source.path).read_bytes()==original
    assert not list((tmp_path/'out').glob('.*.part*'))


def test_actual_ten_bit_preserved(tmp_path):
    p=tmp_path/'10bit.mkv'
    subprocess.run([discover_tool('ffmpeg'),'-v','error','-f','lavfi','-i','testsrc2=size=128x96:rate=5','-t','0.4','-vf','format=yuv420p10le','-c:v','libx265','-threads','2','-x265-params','pools=1:frame-threads=1:log-level=error',str(p)],check=True)
    j=probe_job(p,discover_tool('ffprobe'))
    assert j.bit_depth==10
    caps={'video':{'libx265':('H.265','CPU')},'audio':['aac']}
    out=convert_job(j,Settings(codec='H.265',device='CPU',decode_mode='CPU',output_dir=str(tmp_path/'out')),caps,Control())
    assert probe_job(out,discover_tool('ffprobe')).bit_depth==10


def test_queue_concurrency_pause_cancel_and_failure():
    jobs=[Job(str(i)) for i in range(4)]
    group=QueueControl(); group.queue_paused.set()
    entered=[];completed=[]; maximum=[0]; lock=threading.Lock()
    def worker(job,c):
        try:
            with lock:
                entered.append(job.uid)
                maximum[0]=max(maximum[0],len(group.active))
            while not c.cancel_current.wait(.01):
                c.checkpoint()
        except Cancelled:
            pass
        finally:
            completed.append(job.uid)
            group.unregister(job.uid)
    skipped=[]
    t=threading.Thread(target=run_queue,args=(jobs,2,group,worker,lambda j:skipped.append(j.uid)))
    t.start();time.sleep(.1)
    assert not entered
    group.queue_paused.clear()
    deadline=time.monotonic()+3
    while len(entered)<2 and time.monotonic()<deadline:time.sleep(.01)
    group.queue_paused.set()
    group.cancel(uid=jobs[0].uid)
    deadline=time.monotonic()+3
    while jobs[0].uid not in completed and time.monotonic()<deadline:time.sleep(.01)
    assert jobs[0].uid in completed and jobs[1].uid in group.active
    group.cancel(True);t.join(3)
    assert not t.is_alive() and maximum[0]==2 and len(skipped)==2


def test_false_success_lower_depth_not_published(source,tmp_path,monkeypatch):
    source.bit_depth=10
    caps={'video':{'libx265':('H.265','CPU')},'audio':['aac']}
    def fake(args,*a):
        # Copy an 8-bit source to emulate an encoder silently changing depth.
        Path(args[-1]).write_bytes(Path(source.path).read_bytes())
    monkeypatch.setattr(engine,'run_ffmpeg',fake)
    with pytest.raises(ValueError,match='出力検証失敗'):
        convert_job(source,Settings(codec='H.265',device='CPU',output_dir=str(tmp_path/'out')),caps,Control())
    assert not list((tmp_path/'out').iterdir())


def test_auto_gpu_failure_requires_permission(source,tmp_path,monkeypatch):
    caps={'video':{'h264_amf':('H.264','AMD'),'libx264':('H.264','CPU')},'audio':['aac']}
    calls=[]
    def fail(args,*a):
        calls.append(args[args.index('-c:v')+1])
        raise RuntimeError('driver failed')
    monkeypatch.setattr(engine,'run_ffmpeg',fail)
    with pytest.raises(RuntimeError,match='driver failed'):
        convert_job(source,Settings(output_dir=str(tmp_path/'out')),caps,Control())
    assert calls==['h264_amf']
    assert not list((tmp_path/'out').iterdir())


def test_gui_folder_reorder_audio_restore_and_parallel_actual(source,tmp_path,monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from app import Window,BatchThread
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window,'detect_capabilities',lambda self:None)
    w=Window()
    w.config_path=tmp_path/'settings.json'
    w.log_path=tmp_path/'latest.log'
    w.add_job(source)
    second=copy.deepcopy(source);second.uid='second';second.path=str(tmp_path/'second.mp4')
    Path(second.path).write_bytes(Path(source.path).read_bytes());w.add_job(second)
    w.table.selectRow(1);w.move_selected(-1)
    assert w.jobs[0].uid=='second'
    w.widgets['video_audio'].setCurrentText('そのままコピー')
    w.widgets['parallel_jobs'].setValue(2)
    w.widgets['decode_mode'].setCurrentText('CPU')
    w.save_settings();w.widgets['parallel_jobs'].setValue(1);w.restore()
    assert w.read_settings().parallel_jobs==2 and w.read_settings().video_audio=='copy'
    caps={'video':{'libx264':('H.264','CPU')},'audio':['aac']}
    settings=Settings(output_dir=str(tmp_path/'out'),device='CPU',decode_mode='CPU',parallel_jobs=2,mute=True)
    batch=BatchThread(w.jobs,settings,caps)
    batch.start()
    deadline=time.monotonic()+10
    while batch.isRunning() and time.monotonic()<deadline:
        app.processEvents();time.sleep(.01)
    assert batch.wait(1000)
    app.processEvents()
    assert all(j.status=='完了' for j in w.jobs)
    assert all(not probe_job(j.output,discover_tool('ffprobe')).has_audio for j in w.jobs)
    w.close()


def test_gui_cancel_button_invokes_selected_control(monkeypatch,tmp_path):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from app import Window
    from types import SimpleNamespace
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window,'detect_capabilities',lambda self:None)
    w=Window();w.config_path=tmp_path/'settings.json'
    j=Job(str(tmp_path/'movie.mp4'),kind='動画');w.add_job(j);w.table.selectRow(0)
    group=QueueControl();c=group.register(j.uid)
    w.batch=SimpleNamespace(control=group,isRunning=lambda:False)
    w.cancel_btn.setEnabled(True);w.cancel_btn.click()
    assert c.cancel_current.is_set()
    w.batch=None;w.close()


def test_parallel_retry_answers_are_scoped_to_request(tmp_path):
    from app import BatchThread
    batch=BatchThread([],Settings(),{})
    c=Control()
    requests=[]
    # DirectConnection lets this test model a dialog without an event loop.
    from PySide6.QtCore import Qt
    def answer(request):
        requests.append(request)
        request['allow']=len(requests)==1
        request['reply'].set()
    batch.request_retry.connect(answer,Qt.ConnectionType.DirectConnection)
    assert batch.retry_cpu('first',c) is True
    assert batch.retry_cpu('second',c) is False
    assert requests[0]['reply'] is not requests[1]['reply']
