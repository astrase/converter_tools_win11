import os
from pathlib import Path
import subprocess
import sys
import time

import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine import (Job, Settings, Control, build_command, convert_job, discover_tool,
                    probe_job, stream_bitrate)

CAPS = {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac', 'libmp3lame']}


@pytest.fixture
def source(tmp_path):
    path = tmp_path / '元の 動画.mp4'
    subprocess.run([discover_tool('ffmpeg'), '-v', 'error', '-f', 'lavfi', '-i',
                    'testsrc2=size=160x240:rate=20', '-f', 'lavfi', '-i', 'sine=frequency=440',
                    '-t', '1.5', '-c:v', 'libx264', '-threads', '2', '-b:v', '300k', '-c:a',
                    'aac', '-b:a', '128k', str(path)], check=True)
    return probe_job(path, discover_tool('ffprobe'))


def test_original_video_and_embedded_audio_targets_and_real_conversion(source, tmp_path):
    assert source.video_bps > 0 and source.audio_bps > 0
    s = Settings(output_dir=str(tmp_path / 'out'), device='CPU', rate_mode='ビットレート',
                 video_keep_bitrate=True, video_audio_keep_bitrate=True,
                 video_kbps=1234, video_audio_kbps=64)
    command = build_command(s, source, tmp_path / 'temp.mp4', 'libx264')
    assert command[command.index('-b:v') + 1] == str(source.video_bps)
    assert command[command.index('-b:a') + 1] == str(source.audio_bps)
    out = convert_job(source, s, CAPS, Control())
    result = probe_job(out, discover_tool('ffprobe'))
    assert result.kind == '動画' and result.has_audio and result.duration > 1


def test_original_extracted_audio_target_and_real_conversion(source, tmp_path):
    s = Settings(output_dir=str(tmp_path / 'out'), extract_audio=True, audio_format='m4a',
                 audio_keep_bitrate=True, audio_kbps=64)
    command = build_command(s, source, tmp_path / 'temp.m4a')
    assert command[command.index('-b:a') + 1] == str(source.audio_bps)
    out = convert_job(source, s, CAPS, Control())
    assert probe_job(out, discover_tool('ffprobe')).kind == '音声'


def test_batch_settings_use_each_jobs_own_rate(tmp_path):
    s = Settings(rate_mode='ビットレート', video_keep_bitrate=True, mute=True)
    jobs = [Job(str(tmp_path / f'{i}.mp4'), kind='動画', duration=1, video_bps=rate)
            for i, rate in enumerate([123456, 987654])]
    rates = []
    for job in jobs:
        args = build_command(s, job, tmp_path / 'temp.mp4', 'libx264')
        rates.append(args[args.index('-b:v') + 1])
    assert rates == ['123456', '987654']


@pytest.mark.parametrize('data,expected', [
    ({'bit_rate': '123456'}, 123456),
    ({'bit_rate': 'N/A', 'tags': {'BPS-eng': '345678'}}, 345678),
    ({'tags': {'BPS': '234567'}}, 234567),
    ({'bit_rate': 'N/A'}, 0),
])
def test_stream_metadata(data, expected):
    assert stream_bitrate(data) == expected


def test_unknown_rate_fails_instead_of_using_default_or_total(tmp_path):
    job = Job(str(tmp_path / 'unknown.mp4'), kind='動画', duration=1)
    with pytest.raises(ValueError, match='元の動画ビットレートを取得できません'):
        build_command(Settings(rate_mode='ビットレート', video_keep_bitrate=True), job,
                      tmp_path / 'temp.mp4', 'libx264')
    # A stored check has no effect while quality mode is selected.
    args = build_command(Settings(rate_mode='品質', video_keep_bitrate=True), job,
                         tmp_path / 'temp.mp4', 'libx264')
    assert '-crf' in args


def test_lossless_audio_ignores_flag_and_unsupported_mp3_rate_rejects(tmp_path):
    job = Job(str(tmp_path / 'pcm.wav'), kind='音声', duration=1, has_audio=True, audio_bps=1536000)
    args = build_command(Settings(audio_format='wav', audio_keep_bitrate=True), job, tmp_path / 'temp.wav')
    assert '-b:a' not in args
    with pytest.raises(ValueError, match='MP3の対応範囲'):
        build_command(Settings(audio_format='mp3', audio_keep_bitrate=True), job, tmp_path / 'temp.mp3')


def test_gui_flags_disable_manual_fields_and_restore(tmp_path, monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QStandardPaths
    from app import Window
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(Window, 'detect_capabilities', lambda self: None)
    monkeypatch.setattr(QStandardPaths, 'writableLocation', lambda *a: str(tmp_path / 'settings'))
    w = Window()
    w.widgets['rate_mode'].setCurrentText('ビットレート')
    w.widgets['video_keep_bitrate'].setChecked(True)
    w.widgets['video_audio_keep_bitrate'].setChecked(True)
    w.widgets['audio_keep_bitrate'].setChecked(True)
    w.widgets['audio_format'].setCurrentText('mp3')
    w.widgets['mute'].setChecked(False)
    w.widgets['extract_audio'].setChecked(False)
    w.widgets['video_audio'].setCurrentText('aac')
    assert not w.widgets['video_kbps'].isEnabled()
    assert not w.widgets['audio_kbps'].isEnabled()
    assert not w.widgets['video_audio_kbps'].isEnabled()
    w.widgets['audio_format'].setCurrentText('flac')
    assert not w.widgets['audio_keep_bitrate'].isEnabled()
    w.close()
    restored = Window()
    assert all(restored.widgets[k].isChecked() for k in
               ('video_keep_bitrate', 'video_audio_keep_bitrate', 'audio_keep_bitrate'))
    restored.close()
    app.processEvents()


def test_unknown_original_rate_does_not_stop_rest_of_queue(tmp_path):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from app import BatchThread
    app = QApplication.instance() or QApplication([])
    bad = Job(str(tmp_path / 'unknown.mp4'), kind='動画', duration=1)
    img = tmp_path / '次の画像.png'
    Image.new('RGB', (10, 20), 'red').save(img)
    good = probe_job(img, '')
    batch = BatchThread([bad, good], Settings(output_dir=str(tmp_path / 'out'),
                        rate_mode='ビットレート', video_keep_bitrate=True), CAPS)
    batch.start()
    assert batch.wait(4000)
    assert bad.status == '失敗' and '取得できません' in bad.error
    assert good.status == '完了' and Path(good.output).exists()
    app.processEvents()
