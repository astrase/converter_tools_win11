import sys
from pathlib import Path
import subprocess
import threading
import time
import json
import pytest
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine import *

@pytest.fixture(scope='session')
def caps():
    return check_capabilities(discover_tool('ffmpeg'))

@pytest.fixture
def video(tmp_path):
    path = tmp_path / '日本語 素材.mp4'
    args = [discover_tool('ffmpeg'), '-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=160x240:rate=20',
            '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100', '-t', '3',
            '-c:v', 'libx264', '-threads', '2', '-c:a', 'aac', str(path)]
    subprocess.run(args, check=True, capture_output=True)
    return probe_job(path, discover_tool('ffprobe'))


def data(path):
    return json.loads(subprocess.check_output([discover_tool('ffprobe'), '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)]))


def test_trim_resolution_mute_unicode_and_no_clobber(video, tmp_path, caps):
    video.start, video.end = .5, 1.5
    settings = Settings(output_dir=str(tmp_path / '出力 先'), device='CPU', size_preset='カスタム', width=80, height=120, mute=True)
    original = Path(video.path).read_bytes()
    out = convert_job(video, settings, caps, Control())
    out2 = convert_job(video, settings, caps, Control())
    assert out != out2
    d = data(out)
    assert len(d['streams']) == 1
    assert (d['streams'][0]['width'], d['streams'][0]['height']) == (80, 120)
    assert .9 <= float(d['format']['duration']) <= 1.15
    assert Path(video.path).read_bytes() == original
    assert not list(Path(out).parent.glob('*.part*'))


def test_portrait_preset_and_bitrate(video, tmp_path, caps):
    s = Settings(output_dir=str(tmp_path), device='CPU', size_preset='480p', width=854, height=480, rate_mode='ビットレート', video_kbps=300, fps=10)
    command = build_command(s, video, tmp_path/'part.mp4', 'libx264')
    assert command[command.index('-b:v') + 1] == '300000'
    out = convert_job(video, s, caps, Control())
    stream = data(out)['streams'][0]
    assert stream['height'] > stream['width']
    assert stream['width'] <= 480 and stream['height'] <= 854
    assert stream['avg_frame_rate'] == '10/1'


@pytest.mark.parametrize('fmt', list(AUDIO_FORMATS))
def test_audio_extraction_formats_trim(video, tmp_path, caps, fmt):
    video.start, video.end = .4, 1.4
    s = Settings(output_dir=str(tmp_path), extract_audio=True, audio_format=fmt, sample_rate=48000, channels=1)
    out = convert_job(video, s, caps, Control())
    d = data(out)
    assert all(x['codec_type'] == 'audio' for x in d['streams'])
    assert d['streams'][0]['channels'] == 1
    assert d['streams'][0]['sample_rate'] == '48000'
    assert .9 < float(d['format']['duration']) < 1.2
    audio = probe_job(out, discover_tool('ffprobe'))
    assert audio.kind == '音声'
    second = convert_job(audio, Settings(output_dir=str(tmp_path), audio_format='wav'), caps, Control())
    assert data(second)['streams'][0]['codec_name'] == 'pcm_s16le'


@pytest.mark.parametrize('fmt', IMAGE_FORMATS)
def test_image_conversion(tmp_path, fmt):
    source = tmp_path / '透過 画像.png'
    Image.new('RGBA', (100, 60), (255, 0, 0, 0)).save(source)
    job = probe_job(source, 'not-needed')
    s = Settings(output_dir=str(tmp_path), image_format=fmt, image_width=50, image_height=50, background='#00ff00')
    out = convert_job(job, s, {}, Control())
    with Image.open(out) as im:
        assert im.size == (50, 30)
        if fmt in ('jpg', 'bmp'):
            assert im.convert('RGB').getpixel((10, 10))[1] > 240


def test_exif_and_animation_rejection(tmp_path):
    p = tmp_path/'rotate.jpg'
    exif = Image.Exif()
    exif[274] = 6
    Image.new('RGB',(80,40),'red').save(p,exif=exif)
    job = probe_job(p, '')
    out = convert_job(job,Settings(output_dir=str(tmp_path)),{},Control())
    with Image.open(out) as im:
        assert im.size == (40,80)
    gif = tmp_path/'animated.gif'
    Image.new('RGB',(10,10),'red').save(gif,save_all=True,append_images=[Image.new('RGB',(10,10),'blue')],duration=100,loop=0)
    with pytest.raises(ValueError, match='アニメーション'):
        convert_job(probe_job(gif,''),Settings(output_dir=str(tmp_path),image_format='jpg'),{},Control())
    assert not list(tmp_path.glob('*.part*'))


def test_invalid_trim_and_combination(video, tmp_path):
    video.start, video.end = 2, 1
    with pytest.raises(ValueError):
        build_command(Settings(),video,tmp_path/'x.mp4','libx264')
    video.start, video.end = 0, 0
    with pytest.raises(ValueError):
        build_command(Settings(video_format='webm',codec='H.264'),video,tmp_path/'x.webm','libx264')


def test_gpu_missing_auto_fallback_selection():
    caps = {'video': {'libx264': ('H.264', 'CPU')}, 'audio': ['aac']}
    assert select_encoder(Settings(), caps) == ('libx264', 'CPU')
    with pytest.raises(ValueError):
        select_encoder(Settings(device='NVIDIA'), caps)


def test_actual_gpu_failure_retries_cpu(video,tmp_path,caps,monkeypatch):
    original = run_ffmpeg
    calls = []
    import engine
    def failing_gpu(args,*a,**kw):
        enc = args[args.index('-c:v')+1]
        calls.append(enc)
        if enc == 'h264_nvenc':
            raise RuntimeError('simulated unavailable driver')
        return original(args,*a,**kw)
    monkeypatch.setattr(engine,'run_ffmpeg',failing_gpu)
    fake = copy.deepcopy(caps)
    fake['video']['h264_nvenc'] = ('H.264','NVIDIA')
    out = convert_job(video,Settings(output_dir=str(tmp_path)),fake,Control(),retry_cpu=lambda e: True)
    assert Path(out).exists()
    assert calls == ['h264_nvenc','libx264']
    calls.clear()
    out2 = convert_job(video,Settings(output_dir=str(tmp_path),device='NVIDIA'),fake,Control(),retry_cpu=lambda e: True)
    assert Path(out2).exists() and calls == ['h264_nvenc','libx264']


def test_pause_resume_and_cancel_cleanup(video, tmp_path, caps):
    control = Control()
    result, errors = [], []
    # Slow down a genuine FFmpeg input to make pause/cancel deterministic.
    import engine
    args = build_command(Settings(device='CPU',mute=True), video, tmp_path/'paused.part.mp4', 'libx264')
    args.insert(args.index('-i'), '-re')
    def run():
        try:
            run_ffmpeg(args,3,control,lambda *a:None,lambda *a:None,True)
            result.append(True)
        except Exception as exc:
            errors.append(exc)
    t=threading.Thread(target=run)
    t.start()
    deadline=time.time()+5
    while not control.can_suspend and time.time()<deadline:
        time.sleep(.01)
    assert control.can_suspend
    control.suspend()
    assert control.process_paused
    pid=control.proc.pid
    if os.name != 'nt':
        time.sleep(.1)
        child, state = os.waitpid(pid, os.WUNTRACED | os.WNOHANG)
        assert child == pid and os.WIFSTOPPED(state)
    else:
        assert psutil.Process(pid).status() == psutil.STATUS_STOPPED or control.process_paused
    control.resume()
    assert not control.process_paused
    assert control.proc.pid == pid
    t.join(8)
    assert not t.is_alive() and result and not errors
    (tmp_path/'paused.part.mp4').unlink()
    # Cancel the public conversion path and confirm .part deletion and process exit.
    old = engine.build_command
    def slow(*args,**kwargs):
        command=old(*args,**kwargs)
        command.insert(command.index('-i'),'-re')
        return command
    engine.build_command=slow
    c=Control()
    errors=[]
    def convert():
        try:
            convert_job(video,Settings(device='CPU',output_dir=str(tmp_path)),caps,c)
        except Exception as exc:
            errors.append(exc)
    t=threading.Thread(target=convert)
    try:
        t.start()
        deadline=time.time()+5
        while c.proc is None and time.time()<deadline:
            time.sleep(.01)
        child_process=c.proc
        c.suspend()
        c.cancel(True)
        t.join(8)
        assert not t.is_alive() and isinstance(errors[0],Cancelled)
        assert child_process.poll() is not None
        assert not list(tmp_path.glob('*.part*'))
        assert not list(tmp_path.glob('*_converted*'))
    finally:
        engine.build_command=old


def test_queue_stop_and_cancel():
    c=Control()
    c.queue_paused.set()
    result=[]
    t=threading.Thread(target=lambda: (c.wait_queue(),result.append('resumed')))
    t.start()
    time.sleep(.15)
    assert not result
    c.queue_paused.clear()
    t.join(2)
    assert result == ['resumed']


@pytest.mark.parametrize('fmt,codec',[(f,c) for f,cs in VIDEO_FORMATS.items() for c in cs])
def test_video_container_codec_pairs(video,tmp_path,caps,fmt,codec):
    if not any(pair[0]==codec and pair[1]=='CPU' for pair in caps['video'].values()):
        pytest.skip('CPU encoder unavailable')
    video.end=.5
    s=Settings(output_dir=str(tmp_path),device='CPU',video_format=fmt,codec=codec,video_audio=VIDEO_AUDIO[fmt][0])
    out=convert_job(video,s,caps,Control())
    streams=data(out)['streams']
    expected={'H.264':'h264','H.265':'hevc','VP9':'vp9','AV1':'av1'}[codec]
    assert streams[0]['codec_name']==expected
    assert any(st['codec_type']=='audio' for st in streams)


def test_gpu_retry_declined_does_not_publish(video,tmp_path,caps,monkeypatch):
    import engine
    def fail(*a,**k):
        raise RuntimeError('GPU unavailable')
    monkeypatch.setattr(engine,'run_ffmpeg',fail)
    fake=copy.deepcopy(caps)
    fake['video']['h264_nvenc']=('H.264','NVIDIA')
    with pytest.raises(RuntimeError):
        convert_job(video,Settings(output_dir=str(tmp_path),device='NVIDIA'),fake,Control(),retry_cpu=lambda e: False)
    assert not list(tmp_path.glob('*_converted*'))
    assert not list(tmp_path.glob('*.part*'))
