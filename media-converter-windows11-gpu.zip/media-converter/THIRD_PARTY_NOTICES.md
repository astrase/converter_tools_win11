# Third-party notices

This source distribution does not bundle FFmpeg, Python, PySide6/Qt, Pillow,
psutil or PyInstaller binaries. They are installed separately. The following
links identify upstream projects; they are not a replacement for required
license texts and corresponding source when distributing a binary bundle.

- Python: https://docs.python.org/3/license.html
- PySide6 / Qt: https://doc.qt.io/qtforpython-6/licenses.html
- Pillow: https://github.com/python-pillow/Pillow/blob/main/LICENSE
- psutil: https://github.com/giampaolo/psutil/blob/master/LICENSE
- FFmpeg: https://ffmpeg.org/legal.html
- PyInstaller: https://pyinstaller.org/en/stable/license.html

The PyInstaller build may include Qt Multimedia's own FFmpeg backend libraries.
Those are distinct from the externally selected ffmpeg.exe / ffprobe.exe.
Inspect the build contents and retain their notices, applicable license texts,
and corresponding source information before redistributing.
