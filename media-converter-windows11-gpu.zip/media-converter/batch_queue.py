"""Bounded concurrent queue; each conversion owns its cancellation/process state."""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import threading
import time
from engine import Control, Cancelled


class QueueControl:
    def __init__(self):
        self.lock = threading.RLock()
        self.active = {}
        self.cancel_all = threading.Event()
        self.queue_paused = threading.Event()

    def register(self, uid):
        with self.lock:
            c = Control()
            c.queue_paused = self.queue_paused
            c.cancel_all = self.cancel_all
            if self.cancel_all.is_set():
                c.cancel(True)
            self.active[uid] = c
            return c

    def unregister(self, uid):
        with self.lock:
            self.active.pop(uid, None)

    def cancel(self, all_jobs=False, uid=None):
        with self.lock:
            if all_jobs:
                self.cancel_all.set()
                targets = list(self.active.values())
            elif uid is not None:
                targets = [self.active[uid]] if uid in self.active else []
            else:
                targets = list(self.active.values())[:1]
            for c in targets:
                c.cancel(all_jobs)

    def first(self):
        with self.lock:
            return next(iter(self.active.values()), None)

    @property
    def proc(self):
        c = self.first()
        return c.proc if c else None

    @property
    def process_paused(self):
        c = self.first()
        return c.process_paused if c else False

    def suspend(self):
        c = self.first()
        if c:
            c.suspend()

    def resume(self):
        c = self.first()
        if c:
            c.resume()


def run_queue(jobs, limit, group, worker, skipped):
    """No queued futures beyond capacity, so pausing prevents new launches."""
    pending = iter(jobs)
    exhausted = False
    with ThreadPoolExecutor(max_workers=max(1, min(8, limit))) as pool:
        active = set()
        while active or not exhausted:
            if group.cancel_all.is_set():
                for job in pending:
                    skipped(job)
                exhausted = True
            while not exhausted and not group.queue_paused.is_set() and not group.cancel_all.is_set() and len(active) < max(1, min(8, limit)):
                try:
                    job = next(pending)
                except StopIteration:
                    exhausted = True
                    break
                control = group.register(job.uid)
                active.add(pool.submit(worker, job, control))
            if active:
                done, active = wait(active, timeout=.05, return_when=FIRST_COMPLETED)
                for future in done:
                    future.result()
            elif not exhausted:
                group.cancel_all.wait(.05)
