"""Conservative per-input GPU planning; never infer driver support from a name."""
from dataclasses import dataclass
import math
import os
import re
import subprocess

IS_WINDOWS = os.name == 'nt'


@dataclass
class Pipeline:
    name: str = 'CPU'
    input_args: tuple = ()
    filters: str = ''
    hardware_frames: bool = False
    note: str = ''


def input_depth(stream):
    fmt = stream.get('pix_fmt', '')
    match = re.search(r'(?:p|gray)(9|10|12|14|16)(?:le|be)?$', fmt)
    if match:
        return int(match[1])
    if fmt.startswith('p010'):
        return 10
    if fmt.startswith('p016'):
        return 16
    if fmt in ('yuv420p', 'yuvj420p', 'nv12', 'yuv422p', 'yuv444p', 'rgb24', 'bgr24', 'rgba', 'bgra', 'gray'):
        return 8
    try:
        return int(stream.get('bits_per_raw_sample') or 0)
    except (ValueError, TypeError):
        return 0


def validate_video(settings, job, encoder, caps=None):
    if job.hdr:
        raise ValueError('HDR入力です。この版ではHDRメタデータを確実に維持する変換を未対応としています。無断のSDR化を防ぐため停止しました。')
    if job.bit_depth not in (8, 10):
        raise ValueError('ビット深度が不明、または8/10ビット以外の入力です。安全な変換を判定できません。')
    if job.bit_depth == 10:
        if settings.codec not in ('H.265', 'AV1', 'VP9'):
            raise ValueError('10ビット入力にはH.265/AV1/VP9を選択してください。8ビットへの自動変換は行いません。')
        wanted = 'p010le' if encoder.endswith(('_amf', '_nvenc', '_qsv')) else 'yuv420p10le'
        if encoder.endswith(('_amf', '_nvenc', '_qsv')) and wanted not in (caps or {}).get('pixel_formats', {}).get(encoder, []):
            raise ValueError(f'{encoder}の10ビット対応を確認できません。機能確認を実行するかCPU方式を選んでください。')


def inspect_acceleration(ffmpeg, control, runner, log):
    result = {'hwaccels': [], 'filters': [], 'pixel_formats': {}}
    for flag, key in (('-hwaccels', 'hwaccels'), ('-filters', 'filters')):
        try:
            p = runner([ffmpeg, '-hide_banner', flag], 10, control)
            if not p.returncode:
                output = p.stdout.decode('utf-8', 'replace')
                result[key] = re.findall(r'^\s*(\w+)\s*$', output, re.M) if key == 'hwaccels' else re.findall(r'^\s*[TSC.]{3}\s+(\w+)', output, re.M)
        except subprocess.TimeoutExpired:
            log(f'{flag}の取得がタイムアウトしました')
    return result


def desired_size(settings, job):
    w, h = settings.width, settings.height
    if settings.size_preset != 'カスタム' and job.height > job.width and w > h:
        w, h = h, w
    if not w and not h:
        return job.width, job.height
    ratio = job.width / max(1, job.height)
    if not w:
        w = math.floor(h * ratio / 2) * 2
    elif not h:
        h = math.floor(w / ratio / 2) * 2
    elif settings.keep_aspect:
        factor = min(w / max(1, job.width), h / max(1, job.height))
        w, h = math.floor(job.width * factor / 2) * 2, math.floor(job.height * factor / 2) * 2
    return max(2, w), max(2, h)


def candidates(settings, job, encoder, caps, cpu_filter):
    cpu = Pipeline(filters=cpu_filter, note='デコード: CPU。' + ('サイズ/画素比の補正: CPU。' if cpu_filter else 'サイズ補正なし。'))
    if settings.decode_mode == 'CPU':
        return [cpu]
    routes = []
    accelerators = caps.get('hwaccels', [])
    # Hardware-frame output is forced. A decoder falling back to software cannot
    # quietly satisfy this route, unlike -hwaccel alone.
    eligible = job.video_codec in ('h264', 'hevc', 'av1', 'vp9') and job.bit_depth in (8, 10)
    ordinary = job.sar in ('1:1', '0:1', 'N/A', '') and not job.rotation and job.width % 2 == job.height % 2 == 0
    if eligible and ordinary and encoder.endswith('_amf') and 'amf' in accelerators:
        if cpu_filter and 'vpp_amf' in caps.get('filters', []) and job.bit_depth == 8:
            w, h = desired_size(settings, job)
            routes.append(Pipeline('AMF + GPUサイズ変更', ('-hwaccel', 'amf', '-hwaccel_output_format', 'amf'), f'vpp_amf=w={w}:h={h}:format=nv12', True, 'デコード/サイズ変更/圧縮: AMF GPU'))
        elif not cpu_filter:
            routes.append(Pipeline('AMF', ('-hwaccel', 'amf', '-hwaccel_output_format', 'amf'), '', True, 'デコード/圧縮: AMF GPU、サイズ補正なし'))
    if eligible and IS_WINDOWS and 'd3d11va' in accelerators:
        zero_copy = encoder.endswith('_amf') and not cpu_filter and ordinary
        fmt = 'p010le' if job.bit_depth == 10 else 'nv12'
        chain = '' if zero_copy else ','.join(x for x in (f'hwdownload,format={fmt}', cpu_filter) if x)
        routes.append(Pipeline('D3D11VA', ('-hwaccel', 'd3d11va', '-hwaccel_output_format', 'd3d11'), chain, zero_copy, 'デコード: GPU。' + ('GPUフレームをAMFへ直接渡します。' if zero_copy else 'GPU→メモリ転送あり。サイズ補正・画素変換が必要な場合はCPU。')))
    if eligible and encoder.endswith('_nvenc') and 'cuda' in accelerators:
        zero_copy = not cpu_filter and ordinary
        fmt = 'p010le' if job.bit_depth == 10 else 'nv12'
        chain = '' if zero_copy else ','.join(x for x in (f'hwdownload,format={fmt}', cpu_filter) if x)
        routes.append(Pipeline('CUDA', ('-hwaccel', 'cuda', '-hwaccel_output_format', 'cuda'), chain, zero_copy, 'デコード: NVIDIA GPU。' + ('サイズ補正なし。' if zero_copy else 'サイズ補正: CPU。')))
    if settings.decode_mode == '自動':
        routes.append(cpu)
    if not routes:
        raise ValueError('この入力/FFmpegで利用候補のGPUデコード経路がありません。デコード方式を「自動」または「CPU」にしてください。')
    return routes


def audio_copy_allowed(container, codecs):
    if container == 'mkv':
        return all(c in {'aac', 'mp3', 'mp2', 'opus', 'vorbis', 'flac', 'alac', 'ac3', 'eac3', 'dts', 'truehd', 'pcm_s16le', 'pcm_s24le', 'pcm_s32le', 'pcm_f32le'} for c in codecs)
    allowed = {'mp4': {'aac', 'mp3', 'alac', 'ac3', 'eac3'}, 'mov': {'aac', 'mp3', 'alac', 'pcm_s16le', 'pcm_s24le'}, 'webm': {'opus', 'vorbis'}}
    return bool(codecs) and all(c in allowed.get(container, set()) for c in codecs)
