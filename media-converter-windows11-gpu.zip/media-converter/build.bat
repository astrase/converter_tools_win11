@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo setup.batを先に実行してください。
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m pip install "PyInstaller>=6.11,<7"
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name MediaConverter --collect-all PySide6.QtMultimedia --collect-all PySide6.QtMultimediaWidgets app.py
if errorlevel 1 goto failed
copy /y README.md dist\MediaConverter\README.md >nul
copy /y THIRD_PARTY_NOTICES.md dist\MediaConverter\THIRD_PARTY_NOTICES.md >nul
copy /y LICENSE dist\MediaConverter\LICENSE >nul
copy /y TEST_RESULTS.md dist\MediaConverter\TEST_RESULTS.md >nul
copy /y settings.example.json dist\MediaConverter\settings.example.json >nul
if not exist dist\MediaConverter\tools mkdir dist\MediaConverter\tools
echo dist\MediaConverter\MediaConverter.exe が作成されました。
echo toolsへのFFmpeg配置はREADMEを参照してください。
echo 再配布前に使用ライブラリのライセンス文書・対応するソースの提供方法を確認してください。
pause
exit /b 0
:failed
echo ビルドに失敗しました。上の表示を確認してください。
pause
exit /b 1
