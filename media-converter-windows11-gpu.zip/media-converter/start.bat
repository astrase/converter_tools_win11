@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo 初回はsetup.batを実行してください。
    pause
    exit /b 1
)
.venv\Scripts\python.exe app.py
if errorlevel 1 (
    echo 起動中にエラーが発生しました。上の表示を確認してください。
    pause
    exit /b 1
)
