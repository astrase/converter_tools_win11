"""Local conversion engine; no Qt or network dependency."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass, field
from fractions import Fraction
from PIL import Image, ImageOps, ImageColor
import psutil

ROOT = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
VIDEO_CODECS = {
    'H.264': {'CPU': 'libx264', 'NVIDIA': 'h264_nvenc', 'Intel': 'h264_qsv', 'AMD': 'h264_amf'},
    'H.265': {'CPU': 'libx265', 'NVIDIA': 'hevc_nvenc', 'Intel': 'hevc_qsv', 'AMD': 'hevc_amf'},
    'VP9': {'CPU': 'libvpx-vp9', 'Intel': 'vp9_qsv'},
    'AV1': {'CPU': 'libsvtav1', 'NVIDIA': 'av1_nvenc', 'Intel': 'av1_qsv', 'AMD': 'av1_amf'},
}
VIDEO_FORMATS = {'mp4': ['H.264', 'H.265', 'AV1'], 'mkv': list(VIDEO_CODECS),
                 'mov': ['H.264', 'H.265'], 'webm': ['VP9', 'AV1']}
VIDEO_AUDIO = {'mp4': ['aac'], 'mov': ['aac', 'pcm_s16le'],
               'mkv': ['aac', 'libopus', 'flac', 'pcm_s16le'], 'webm': ['libopus']}
AUDIO_FORMATS = {'mp3': 'libmp3lame', 'wav': 'pcm_s16le', 'flac': 'flac', 'm4a': 'aac', 'aac': 'aac', 'opus': 'libopus'}
IMAGE_FORMATS = ['png', 'jpg', 'webp', 'bmp', 'tiff']


def subprocess_options():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def discover_tool(name, override=''):
    if override:
        p = Path(override).expanduser()
        if not p.is_file():
            raise ValueError(f'{name}が見つかりません: {p}')
        return str(p.resolve())
    for folder in (ROOT / 'tools', ROOT):
        p = folder / (name + ('.exe' if os.name == 'nt' else ''))
        if p.is_file():
            return str(p)
    p = shutil.which(name)
    if not p:
        raise ValueError(f'{name}が未設定です。toolsフォルダーへ配置するか、設定で実行ファイルを指定してください。')
    return p


@dataclass
class Settings:
    output_dir: str = ''
    same_folder: bool = False
    ffmpeg: str = ''
    ffprobe: str = ''
    extract_audio: bool = False
    video_format: str = 'mp4'
    codec: str = 'H.264'
    device: str = '自動'
    size_preset: str = '元のサイズ'
    width: int = 0
    height: int = 0
    keep_aspect: bool = True
    rate_mode: str = '品質'
    quality: int = 23
    video_kbps: int = 5000
    fps: float = 0
    mute: bool = False
    video_audio: str = 'aac'
    video_audio_kbps: int = 192
    audio_kbps: int = 192
    audio_format: str = 'mp3'
    sample_rate: int = 0
    channels: int = 0
    image_format: str = 'png'
    image_width: int = 0
    image_height: int = 0
    image_aspect: bool = True
    image_quality: int = 90
    background: str = '#ffffff'

    @classmethod
    def from_dict(cls, data):
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Job:
    path: str
    kind: str = '調査中'
    duration: float = 0
    width: int = 0
    height: int = 0
    has_audio: bool = False
    start: float = 0
    end: float = 0  # zero: full duration
    status: str = '待機'
    progress: int = 0
    output: str = ''
    error: str = ''
    uid: str = field(default_factory=lambda: uuid.uuid4().hex)


class Cancelled(Exception):
    pass


class Control:
    """Only this task's child process is suspended/terminated. No arbitrary PID."""
    def __init__(self):
        self.lock = threading.RLock()
        self.proc = None
        self.process_paused = False
        self.cancel_current = threading.Event()
        self.cancel_all = threading.Event()
        self.queue_paused = threading.Event()
        self.can_suspend = False

    def set_process(self, proc, can_suspend=False):
        with self.lock:
            self.proc = proc
            self.can_suspend = can_suspend
            self.process_paused = False
            if proc and (self.cancel_current.is_set() or self.cancel_all.is_set()):
                proc.terminate()

    def checkpoint(self):
        if self.cancel_current.is_set() or self.cancel_all.is_set():
            raise Cancelled()

    def suspend(self):
        with self.lock:
            if not self.can_suspend or not self.proc or self.proc.poll() is not None:
                raise ValueError('現在の処理は一時停止できません。キュー停止を使用してください。')
            if not self.process_paused:
                psutil.Process(self.proc.pid).suspend() if os.name == 'nt' else os.kill(self.proc.pid, signal.SIGSTOP)
                self.process_paused = True

    def resume(self):
        with self.lock:
            if self.process_paused and self.proc:
                try:
                    psutil.Process(self.proc.pid).resume() if os.name == 'nt' else os.kill(self.proc.pid, signal.SIGCONT)
                except (psutil.NoSuchProcess, ProcessLookupError):
                    pass
            self.process_paused = False

    def cancel(self, all_jobs=False):
        if all_jobs:
            self.cancel_all.set()
        self.cancel_current.set()
        with self.lock:
            self.resume()
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.kill()
                except ProcessLookupError:
                    pass

    def wait_queue(self):
        while self.queue_paused.is_set() and not self.cancel_all.is_set():
            time.sleep(.1)
        if self.cancel_all.is_set():
            raise Cancelled()


def probe_job(path, ffprobe, control=None):
    job = Job(str(Path(path).resolve()))
    try:
        with Image.open(path) as im:
            job.kind = '画像'
            job.width, job.height = ImageOps.exif_transpose(im).size
            return job
    except (OSError, ValueError):
        pass
    args = [ffprobe, '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **subprocess_options())
    if control:
        control.set_process(proc)
    try:
        stdout, stderr = proc.communicate(timeout=20)
        if control:
            control.checkpoint()
        if proc.returncode:
            raise ValueError('メディア情報を取得できません: ' + stderr.decode('utf-8', 'replace')[-1200:])
        data = json.loads(stdout)
        streams = data.get('streams', [])
        videos = [s for s in streams if s.get('codec_type') == 'video' and not s.get('disposition', {}).get('attached_pic')]
        audio = [s for s in streams if s.get('codec_type') == 'audio']
        if not videos and not audio:
            raise ValueError('対応する動画・音声ストリームがありません。')
        job.kind = '動画' if videos else '音声'
        job.has_audio = bool(audio)
        job.duration = float(data.get('format', {}).get('duration') or max([float(s.get('duration') or 0) for s in streams], default=0))
        if videos:
            job.width, job.height = int(videos[0].get('width', 0)), int(videos[0].get('height', 0))
            try:
                sar = Fraction(videos[0].get('sample_aspect_ratio', '1:1').replace(':', '/'))
                if sar > 0:
                    job.width = round(job.width * float(sar))
            except (ValueError, ZeroDivisionError):
                pass
            rotation = videos[0].get('tags', {}).get('rotate', 0)
            for side in videos[0].get('side_data_list', []):
                rotation = side.get('rotation', rotation)
            if int(float(rotation)) % 180:
                job.width, job.height = job.height, job.width
        return job
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise ValueError('情報取得が20秒でタイムアウトしました。')
    finally:
        if control:
            control.set_process(None)


def quality_args(encoder, value):
    if encoder.endswith('_nvenc'):
        return ['-rc', 'vbr', '-cq', str(value), '-b:v', '0']
    if encoder.endswith('_qsv'):
        return ['-global_quality', str(value)]
    if encoder.endswith('_amf'):
        return ['-rc', 'cqp', '-qp_i', str(value), '-qp_p', str(value)]
    if encoder == 'libvpx-vp9':
        return ['-crf', str(value), '-b:v', '0', '-deadline', 'good', '-cpu-used', '4']
    if encoder == 'libsvtav1':
        return ['-crf', str(value), '-preset', '10', '-threads', '2', '-svtav1-params', 'lp=2']
    return ['-crf', str(value), '-preset', 'medium', '-threads', '2']


def encoder_candidates():
    result = {enc: (codec, device) for codec, devices in VIDEO_CODECS.items() for device, enc in devices.items()}
    result['libaom-av1'] = ('AV1', 'CPU')
    return result


def checked_process(args, timeout, control):
    """Bounded, cancellable child; always reap it before returning."""
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **subprocess_options())
    control.set_process(proc)
    deadline = time.monotonic() + timeout
    try:
        while True:
            control.checkpoint()
            try:
                stdout, stderr = proc.communicate(timeout=min(.1, max(.001, deadline - time.monotonic())))
                control.checkpoint()
                return subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                if time.monotonic() >= deadline:
                    raise subprocess.TimeoutExpired(args, timeout)
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.communicate()
        control.set_process(None)


def check_capabilities(ffmpeg, callback=lambda *a: None, stop=None, control=None):
    control = control or Control()
    available, reasons = {}, {}
    proc = checked_process([ffmpeg, '-hide_banner', '-encoders'], 15, control)
    if proc.returncode:
        raise ValueError('FFmpegのエンコーダー一覧を取得できません。')
    listed = set(re.findall(r'^\s*[VAS][A-Z.]{5}\s+(\S+)', proc.stdout.decode('utf-8', 'replace'), re.M))
    for encoder, pair in encoder_candidates().items():
        if stop and stop.is_set():
            break
        if encoder not in listed:
            reasons[encoder] = 'このFFmpegに含まれていません'
            continue
        callback(f'{encoder}を試験中…')
        q = quality_args(encoder, 28) if encoder != 'libaom-av1' else ['-crf', '28', '-b:v', '0', '-cpu-used', '8', '-threads', '2']
        args = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i',
                'color=size=128x128:rate=10', '-frames:v', '2', '-an', '-c:v', encoder, '-pix_fmt', 'yuv420p', *q, '-f', 'null', '-']
        try:
            trial = checked_process(args, 8, control)
            if trial.returncode:
                reasons[encoder] = trial.stderr.decode('utf-8', 'replace')[-700:] or '試験エンコードに失敗'
            else:
                available[encoder] = pair
        except subprocess.TimeoutExpired:
            reasons[encoder] = '試験が8秒でタイムアウト'
    # audio encoders: list presence; actual errors are reported per job
    audio = {enc for enc in AUDIO_FORMATS.values() if enc in listed}
    return {'video': available, 'audio': sorted(audio), 'reasons': reasons}


def select_encoder(settings, caps, cpu_only=False):
    requested = 'CPU' if cpu_only else settings.device
    matches = [(enc, pair[1]) for enc, pair in caps['video'].items() if pair[0] == settings.codec]
    priority = ['NVIDIA', 'Intel', 'AMD', 'CPU'] if requested == '自動' else [requested]
    for device in priority:
        for enc, d in matches:
            if d == device:
                return enc, d
    raise ValueError(f'{settings.codec} / {requested}に利用可能なエンコーダーがありません。機能確認を実行してください。')


def trim_length(job):
    if job.start < 0 or job.end < 0 or (job.end and job.end <= job.start):
        raise ValueError('トリミング開始・終了位置が不正です。')
    if job.duration and (job.start >= job.duration or job.end > job.duration + .05):
        raise ValueError('トリミング範囲が素材の長さを超えています。')
    if not job.duration and (job.start or job.end):
        if not job.end:
            raise ValueError('長さ不明の素材は終了位置も指定してください。')
    return (job.end or job.duration) - job.start


def scale_filter(settings, job):
    # Normalize non-square pixels before fitting; merely setsar=1 would stretch them.
    normalize = "scale=w='max(2,trunc(iw*if(gt(sar,0),sar,1)/2)*2)':h='max(2,trunc(ih/2)*2)',setsar=1,"
    w, h = settings.width, settings.height
    if settings.size_preset != 'カスタム' and job.height > job.width and w > h:
        w, h = h, w
    if not w and not h:
        return normalize.rstrip(',')
    if not w:
        return normalize + f'scale=-2:{h},setsar=1'
    if not h:
        return normalize + f'scale={w}:-2,setsar=1'
    if settings.keep_aspect:
        return normalize + f'scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1'
    return normalize + f'scale={w}:{h},setsar=1'


def build_command(settings, job, temp, encoder=''):
    ffmpeg = discover_tool('ffmpeg', settings.ffmpeg)
    length = trim_length(job)
    is_audio = job.kind == '音声' or settings.extract_audio
    args = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin', '-n', '-i', job.path]
    if job.start:
        args += ['-ss', str(job.start)]  # output seeking: decode for accurate cuts
    if job.end:
        args += ['-t', str(length)]
    if is_audio:
        if not job.has_audio:
            raise ValueError('この素材には音声がありません。')
        codec = AUDIO_FORMATS[settings.audio_format]
        args += ['-map', '0:a:0', '-vn', '-c:a', codec]
        if codec not in ('flac', 'pcm_s16le'):
            args += ['-b:a', f'{settings.audio_kbps}k']
        if settings.sample_rate:
            args += ['-ar', str(settings.sample_rate)]
        if settings.channels:
            args += ['-ac', str(settings.channels)]
    else:
        if settings.codec not in VIDEO_FORMATS.get(settings.video_format, []):
            raise ValueError('動画形式とコーデックの組み合わせが不正です。')
        if not encoder:
            raise ValueError('動画エンコーダーが未選択です。')
        args += ['-map', '0:V:0', '-c:v', encoder, '-pix_fmt', 'yuv420p', '-vf', scale_filter(settings, job)]
        if settings.rate_mode == 'ビットレート':
            args += ['-b:v', f'{settings.video_kbps}k']
        elif encoder == 'libaom-av1':
            args += ['-crf', str(settings.quality), '-b:v', '0', '-cpu-used', '8', '-threads', '2']
        else:
            args += quality_args(encoder, settings.quality)
        if settings.fps:
            args += ['-r', str(settings.fps)]
        if settings.mute or not job.has_audio:
            args += ['-an']
        else:
            if settings.video_audio not in VIDEO_AUDIO[settings.video_format]:
                raise ValueError('動画形式と音声コーデックの組み合わせが不正です。')
            args += ['-map', '0:a:0?', '-c:a', settings.video_audio]
            if settings.video_audio not in ('flac', 'pcm_s16le'):
                args += ['-b:a', f'{settings.video_audio_kbps}k']
        if settings.codec == 'H.265' and settings.video_format in ('mp4', 'mov'):
            args += ['-tag:v', 'hvc1']
        if settings.video_format in ('mp4', 'mov'):
            args += ['-movflags', '+faststart']
    return args + ['-progress', 'pipe:1', '-nostats', str(temp)]


def unique_output(job, settings):
    ext = settings.image_format if job.kind == '画像' else settings.audio_format if job.kind == '音声' or settings.extract_audio else settings.video_format
    folder = Path(job.path).parent if settings.same_folder else Path(settings.output_dir or (Path(job.path).parent / 'converted'))
    folder.mkdir(parents=True, exist_ok=True)
    base = folder / (Path(job.path).stem + '_converted.' + ext)
    return base


def publish_file(temp, base):
    """Atomic, no-clobber publication on NTFS and normal local file systems."""
    for n in range(100000):
        target = base if not n else base.with_name(f'{base.stem}_{n}{base.suffix}')
        try:
            os.link(temp, target)
            temp.unlink()
            return target
        except FileExistsError:
            continue
        except OSError as exc:
            # Windows rename is also atomic and refuses an existing destination.
            if os.name == 'nt':
                try:
                    os.rename(temp, target)
                    return target
                except FileExistsError:
                    continue
            raise ValueError('出力先が安全な完成ファイル作成に対応していません。NTFSなどのローカルフォルダーを選んでください。') from exc
    raise ValueError('出力名を確保できません。')


def convert_image(job, settings, temp, control):
    control.checkpoint()
    fmt = settings.image_format
    frames, durations = [], []
    with Image.open(job.path) as source:
        count = getattr(source, 'n_frames', 1)
        animated = bool(getattr(source, 'is_animated', False)) and source.format != 'TIFF'
        if count > 1 and fmt not in ('png', 'webp', 'tiff'):
            raise ValueError('アニメーション・複数ページ画像はPNG / WebP / TIFFのみ対応します。最初のフレームだけを保存しません。')
        if count > 1 and not animated and fmt != 'tiff':
            raise ValueError('複数ページ画像の出力はTIFFのみ対応します。')
        if count > 500 or source.width * source.height * count > 100_000_000:
            raise ValueError('画像の総画素数またはフレーム数が上限を超えています（1億画素 / 500フレーム）。')
        loop = source.info.get('loop', 1)
        poster = bool(source.info.get('default_image', False))
        for index in range(count):
            control.checkpoint()
            source.seek(index)
            if poster and index == 0 and fmt == 'webp':
                continue  # APNG poster is not part of the timed animation.
            im = ImageOps.exif_transpose(source).convert('RGBA')
            w, h = settings.image_width, settings.image_height
            if w or h:
                if settings.image_aspect:
                    factor = min(w / im.width if w else float('inf'), h / im.height if h else float('inf'))
                    size = (max(1, round(im.width * factor)), max(1, round(im.height * factor)))
                else:
                    size = (w or im.width, h or im.height)
                im = im.resize(size, Image.Resampling.LANCZOS)
            if fmt in ('jpg', 'bmp'):
                bg = Image.new('RGB', im.size, ImageColor.getrgb(settings.background))
                bg.paste(im, mask=im.getchannel('A'))
                im = bg
            frames.append(im)
            durations.append(source.info.get('duration', 100))
    control.checkpoint()
    options = {'quality': settings.image_quality} if fmt in ('jpg', 'webp') else {}
    if fmt == 'tiff':
        options['compression'] = 'tiff_deflate'
    if len(frames) > 1:
        options.update(save_all=True, append_images=frames[1:])
        if fmt in ('png', 'webp'):
            options.update(duration=durations[1:] if poster and fmt == 'png' else durations, loop=loop)
        if fmt == 'png':
            options.update(default_image=poster, disposal=0, blend=0)
    frames[0].save(temp, **options)
    control.checkpoint()


def run_ffmpeg(args, length, control, callback, log, cpu):
    log('実行: ' + subprocess.list2cmdline(args))
    with tempfile.TemporaryFile() as error_file:
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=error_file, text=True,
                                encoding='utf-8', errors='replace', **subprocess_options())
        control.set_process(proc, can_suspend=cpu)
        data = {}
        try:
            for line in proc.stdout:
                control.checkpoint()
                key, _, value = line.strip().partition('=')
                data[key] = value
                if key == 'progress':
                    try:
                        seconds = int(data.get('out_time_us', 0)) / 1_000_000
                        speed = float(data.get('speed', '0').rstrip('x'))
                    except ValueError:
                        seconds, speed = 0, 0
                    percent = min(99, max(0, int(100 * seconds / length))) if length > 0 else 0
                    remaining = max(0, (length - seconds) / speed) if length > 0 and speed > 0 else None
                    callback(percent, f'{speed:.2f}倍速 / 残り約{remaining:.0f}秒' if remaining is not None else '処理中（残り時間不明）')
            code = proc.wait()
            control.checkpoint()
            if code:
                error_file.seek(0)
                detail = error_file.read().decode('utf-8', 'replace')[-6000:]
                raise RuntimeError(detail or f'FFmpeg終了コード: {code}')
        finally:
            if proc.poll() is None:
                control.resume()
                proc.kill()
                proc.wait(timeout=5)
            proc.stdout.close()
            control.set_process(None)


def convert_job(job, settings, caps, control, progress=lambda *a: None,
                log=lambda *a: None, encoder_changed=lambda *a: None, retry_cpu=lambda *a: False):
    control.checkpoint()
    base = unique_output(job, settings)
    temp = base.with_name(f'.{base.stem}.{uuid.uuid4().hex}.part{base.suffix}')
    try:
        if job.kind == '画像':
            encoder_changed('Pillow', False)
            convert_image(job, settings, temp, control)
        else:
            encoder, device = ('', 'CPU')
            if job.kind == '動画' and not settings.extract_audio:
                encoder, device = select_encoder(settings, caps)
            else:
                if AUDIO_FORMATS[settings.audio_format] not in caps['audio']:
                    raise ValueError('指定した音声エンコーダーがこのFFmpegにありません。')
            if job.kind == '動画' and not settings.extract_audio and not settings.mute and job.has_audio and settings.video_audio not in caps['audio']:
                raise ValueError('指定した動画用音声エンコーダーがこのFFmpegにありません。')
            encoder_changed(encoder or AUDIO_FORMATS[settings.audio_format], device == 'CPU')
            try:
                run_ffmpeg(build_command(settings, job, temp, encoder), trim_length(job), control, progress, log, device == 'CPU')
            except RuntimeError as exc:
                if device == 'CPU':
                    raise
                control.checkpoint()
                try:
                    cpu_encoder, _ = select_encoder(settings, caps, cpu_only=True)
                except ValueError:
                    raise exc
                if settings.device != '自動' and not retry_cpu(str(exc)):
                    control.checkpoint()
                    raise exc
                log('GPU変換に失敗。CPUで再試行: ' + str(exc))
                temp.unlink(missing_ok=True)
                encoder_changed(cpu_encoder, True)
                run_ffmpeg(build_command(settings, job, temp, cpu_encoder), trim_length(job), control, progress, log, True)
        control.checkpoint()
        if not temp.is_file() or temp.stat().st_size == 0:
            raise ValueError('出力ファイルが空です。')
        output = publish_file(temp, base)
        progress(100, '完了')
        return str(output)
    finally:
        temp.unlink(missing_ok=True)
