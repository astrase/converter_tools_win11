@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "MC_PYTHON=py -3"
py -3 -c "import sys; assert sys.version_info >= (3,11)" >nul 2>&1
if errorlevel 1 (
    set "MC_PYTHON=python"
    python -c "import sys; assert sys.version_info >= (3,11)" >nul 2>&1
    if errorlevel 1 goto missing_python
)
echo 仮想環境を作成しています...
if not exist ".venv\Scripts\python.exe" (
    %MC_PYTHON% -m venv .venv
    if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -c "import sys; assert sys.version_info >= (3,11)" >nul 2>&1
if errorlevel 1 goto old_venv
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo セットアップ完了。start.batをダブルクリックしてください。
echo 動画・音声用にtoolsへffmpeg.exeとffprobe.exeを配置してください。
pause
exit /b 0
:missing_python
echo Python 3.11以上の64-bit版を https://www.python.org/downloads/windows/ からインストールしてください。
echo インストール時にAdd python.exe to PATHを選ぶと便利です。
pause
exit /b 1
:old_venv
echo この仮想環境のPythonが古いです。.venvフォルダーを削除して再実行してください。
pause
exit /b 1
:failed
echo セットアップに失敗しました。上のエラーを確認してください。
pause
exit /b 1
